<!-- ####################################### -->
<!-- 

Made By: Md Hasibuzzaman
Date: 09/09/2019 
Phone: 01738346180

-->
<!-- #################################### -->
<?php
 session_start();
?>
<?php
require "../database.php";
?>
<?php
if (isset($_POST['SubBtn'])) {
  $error = false;
  require "../database.php";
  // $emp_id = $conn->real_escape_string($_POST['emp_id']);
  $user_name = $conn->real_escape_string($_POST['user_name']);
  $password = $_POST['password'];
  $job_title_no = $conn->real_escape_string($_POST['job_title_no']);
  $join_date = $conn->real_escape_string($_POST['join_date']);
  $f_name = $conn->real_escape_string($_POST['f_name']);
  $l_name = $conn->real_escape_string($_POST['l_name']);
  $father_name = $conn->real_escape_string($_POST['father_name']);
  $mother_name = $conn->real_escape_string($_POST['mother_name']);
  $husband_name = $conn->real_escape_string($_POST['husband_name']);
  $gender = $conn->real_escape_string($_POST['gender']);
  $dob = $conn->real_escape_string($_POST['dob']);
  $blood_group = $conn->real_escape_string($_POST['blood_group']);
  $religion = $conn->real_escape_string($_POST['religion']);
  $marital_status = $conn->real_escape_string($_POST['marital_status']);
  $email_personal = $conn->real_escape_string($_POST['email_personal']);
  $email_official = $conn->real_escape_string($_POST['email_official']);
  $phone_home = $conn->real_escape_string($_POST['phone_home']);
  $phone_mobile = $conn->real_escape_string($_POST['phone_mobile']);
  $phone_office = $conn->real_escape_string($_POST['phone_office']);
  $nationality = $conn->real_escape_string($_POST['nationality']);
  $village = $conn->real_escape_string($_POST['village']);
  $division = $conn->real_escape_string($_POST['division']);
  $district = $conn->real_escape_string($_POST['district']);
  $upazila = $conn->real_escape_string($_POST['upazila']);
  $p_office = $conn->real_escape_string($_POST['p_office']);
  $p_code = $conn->real_escape_string($_POST['p_code']);
  $p_village = $conn->real_escape_string($_POST['p_village']);
  $p_division = $conn->real_escape_string($_POST['p_division']);
  $p_district = $conn->real_escape_string($_POST['p_district']);
  $p_upazila = $conn->real_escape_string($_POST['p_upazila']);
  $p_p_office = $conn->real_escape_string($_POST['p_p_office']);
  $p_p_code = $conn->real_escape_string($_POST['p_p_code']);
  $reporting_to = $conn->real_escape_string($_POST['reporting_to']);
  $sa_last_login = $conn->real_escape_string($_POST['sa_last_login']);
  $active_status = $conn->real_escape_string($_POST['active_status']);
  $sa_role_no = $conn->real_escape_string($_POST['sa_role_no']);
  $nid = $conn->real_escape_string($_POST['nid']);
  $passport_no = $conn->real_escape_string($_POST['passport_no']);
  $driving_lc_no = $conn->real_escape_string($_POST['driving_lc_no']);
  $tin_no = $conn->real_escape_string($_POST['tin_no']);
  $next_incr_date = $conn->real_escape_string($_POST['next_incr_date']);
  $m_status = $conn->real_escape_string($_POST['m_status']);
  

  $insertQuery = "INSERT INTO `sm_hr_emp` VALUES (NULL,'$user_name','$password','$job_title_no','$join_date','$f_name','$l_name','$father_name','$mother_name','$husband_name','$gender','$dob','$blood_group','$religion','$marital_status','$email_personal','$email_official','$phone_home','$phone_mobile','$phone_office','$nationality','$village','$division','$district','$upazila','$p_office','$p_code','$p_village','$p_division','$p_district','$p_upazila','$p_p_office','$p_p_code','$reporting_to','$sa_last_login','$active_status','$sa_role_no','$nid','$passport_no','$driving_lc_no','$tin_no','$next_incr_date','$m_status','',now(), '', now())";
  // echo $insertQuery;exit;
  $conn->query($insertQuery);

  if ($conn->affected_rows == 1) {
    $message = "Save Successfully";
    header("Location:hr_emp.php");
  }
  // $conn->close();
  
}
?>
<?php

$query = "Select Max(emp_id) From sm_hr_emp";
$returnD = mysqli_query($conn, $query);
$result = mysqli_fetch_assoc($returnD);
$maxRows = $result['Max(emp_id)'];
if (empty($maxRows)) {
  $lastRow = $maxRows = 1;
} else {
  $lastRow = $maxRows + 1;
}
// $conn->close();
?>
<?php
require "../source/top.php";
?>
<?php
require "../source/header.php";
require "../source/sidebar.php";
?>
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i> Member Registration</h1>
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <!-- -------------------------------->
      <?php if (isset($message)) echo $message; ?>
      <form action="" method="post">
        <!-- emp_id user name part -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">EMP ID</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" class="form-control" required autofocus placeholder="ID" value=<?php if (!empty($lastRow)) {echo $lastRow;} ?> readonly>

          </div>
          <!-- script start -->
          <script>
            function checkUserAvailability() {
              $("#loaderIcon").show();
              jQuery.ajax({
                url: "check_availability.php",
                data: 'userid=' + $("#userid").val(),
                type: "POST",
                success: function(data) {
                  $("#user-availability-status").html(data);
                  $("#loaderIcon").hide();
                },
                error: function() {}
              });
            }
          </script>
          <!-- script stop -->
          <label class="col-sm-2 col-form-label">user_name</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="user_name" id="userid" class="form-control" onBlur="checkUserAvailability()" placeholder="username" required>
            <tr>
              <th width="24%" scope="row"></th>
              <td><span id="user-availability-status"></span></td>
            </tr>
          </div>
        </div>
        <!-- password part  -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Password</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="password" class="form-control" id="memid">
          </div>
          <label class="col-sm-2 col-form-label">Retype Password</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="" class="form-control" readonly>
          </div>
        </div>
        <!-- job_title -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Job Title</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="job_title_no" class="form-control">
          </div>
          <label class="col-sm-2 col-form-label">Join Date</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="date" name="join_date" class="form-control">
            <!------------------------------------->
          </div>
        </div>
        <!-- Name part -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">First Name</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="f_name" class="form-control" style="" placeholder="Full Name" required>
          </div>
          <label class="col-sm-2 col-form-label">Last Name</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="l_name" class="form-control" placeholder="Last Name" required>
          </div>
        </div>
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Father Name</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="father_name" class="form-control" placeholder="Father Name" required>
          </div>
          <label class="col-sm-2 col-form-label">Mother Name</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="mother_name" class="form-control" placeholder="Mother Name">
          </div>
        </div>
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Husband Name</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="husband_name" class="form-control" placeholder="Husband Name" required>
          </div>
          <label class="col-sm-2 col-form-label">Gender</label>
          <label for="" class="col-form-label">:</label>
          <div class="col">
            <select name="gender" class="form-control">
              <option value="">----Select any----</option>
              <option value="1">Male</option>
              <option value="2">Female</option>
              <option value="3">Other</option>
            </select>
          </div>
        </div>
        <!-- date of birth and blood group part -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Date OF Birth</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="date" name="dob" class="form-control" required>
          </div>
          <label class="col-sm-2 col-form-label">Blood Group</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <select name="blood_group" class="form-control" required>
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
          </div>
        </div>
        <!-- religion nationality part -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Religion</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <select name="religion" class="form-control" required>
              <option value="Islam">Islam</option>
              <option value="Hinduism">Hinduism</option>
              <option value="Buddhism">Buddhism</option>
              <option value="Christianity">Christianity</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <label class="col-sm-2 col-form-label">Marital Status</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <select name="marital_status" id="" class="form-control">
              <option value="">---select---</option>
              <option value="unmarried">Unmarid</option>
              <option value="married">Married</option>
              <option value="widow">Widow</option>
              <option value="divorced">Divorced</option>
            </select>
          </div>
        </div>
        <!-- Email part -->
        <!-- script start -->
        <script>
          function checkemailAvailability() {
            $("#loaderIcon").show();
            jQuery.ajax({
              url: "check_availability.php",
              data: 'emailid=' + $("#emailid").val(),
              type: "POST",
              success: function(data) {
                $("#email-availability-status").html(data);
                $("#loaderIcon").hide();
              },
              error: function() {}
            });
          }
        </script>
        <!-- script stop -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Email Personal</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="email" name="email_personal" class="form-control" id="emailid" onBlur="checkemailAvailability()" placeholder="admin@domain.com" required>
            <tr>
              <th width="24%" scope="row"></th>
              <td><span id="email-availability-status"></span></td>
            </tr>
          </div>
          <!-- script start -->
          <script>
            function checkemailAvailabilityp() {
              $("#loaderIcon").show();
              jQuery.ajax({
                url: "check_availability.php",
                data: 'pemailid=' + $("#pemailid").val(),
                type: "POST",
                success: function(data) {
                  $("#email-availability-statusp").html(data);
                  $("#loaderIcon").hide();
                },
                error: function() {}
              });
            }
          </script>
          <!-- script end  -->
          <label class="col-sm-2 col-form-label">Email Office</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="email" name="email_official" class="form-control" id="pemailid" onBlur="checkemailAvailabilityp()" placeholder="admin@domain.com" required>
            <tr>
              <th width="24%" scope="row"></th>
              <td><span id="email-availability-statusp"></span></td>
            </tr>
          </div>
        </div>
        <!-- phone no  -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Phone Home</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="tel" id="" name="phone_home" class="form-control">
          </div>
          <label class="col-sm-2 col-form-label">Mobile No</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="tel" id="" name="phone_mobile" class="form-control">
          </div>
        </div>

        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Phone Office</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="tel" id="" name="phone_office" class="form-control" required>
          </div>
          <label class="col-sm-2 col-form-label">Nationality</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <select name="nationality" id="" class="form-control">
              <option value="Bangladeshi">Bangladeshi</option>
            </select>
          </div>
        </div>
        <!-- address part -->
        <div class="form-row form-group">
          <div class="col-sm-6">
            <div class="card">
              <div class="card-header">
                Present Address
              </div>
              <div class="card-body">
                <!--------------------address script and php query---------------------------->
                <?php
                require_once("../dbcontroller.php");
                $db_handle = new DBController();
                $query = "SELECT * FROM divisions";
                $results = $db_handle->runQuery($query);
                ?>
                <!------------------------------------------------>
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Village/Road/House/Flat</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <input type="text" class="form-control" name="village" placeholder="Village/Road#/House#/Flat#" required>
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Division</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <select name="division" id="division-list" required class="form-control" onChange="getDistrict(this.value);">
                      <option value="">Select Division</option>
                      <?php
                      foreach ($results as $division) {
                        ?>
                        <option value="<?php echo $division["id"]; ?>"><?php echo $division["name"]; ?></option>
                      <?php
                      }
                      ?>
                    </select>
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Dristrict</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <select name="district" id="district-list" required class="form-control" onChange="getUpazilas(this.value);">
                      <option value="">Select Distict</option>
                    </select>
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">P.S./Upazila</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <select name="upazila" id="upazilla-list" required class="form-control">
                      <option value="">Select Upazila</option>
                    </select>
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Post Office</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <input type="text" name="p_office" required class="form-control">
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Post Code</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <input type="text" name="p_code" class="form-control" required>
                  </div>
                </div>
                <!--------------------------------------------->
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="card">
              <div class="card-header">
                Parmanant Address
              </div>
              <div class="card-body">
                <!------------------------------------------------>
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Village/Road/House/Flat</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <input type="text" name="p_village" class="form-control" required placeholder="Village/Road#/House#/Flat#">
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Division</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <select name="p_division" id="division-list1" required class="form-control" onChange="getDistrict1(this.value);">
                      <option value="">Select Division</option>
                      <?php
                      foreach ($results as $division) {
                        ?>
                        <option value="<?php echo $division["id"]; ?>"><?php echo $division["name"]; ?></option>
                      <?php
                      }
                      ?>
                    </select>
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Dristrict</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <select name="p_district" id="district-list1" required class="form-control" onChange="getUpazilas1(this.value);">
                      <option value="">Select District</option>
                    </select>
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">P.S./Upazila</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <select name="p_upazila" id="upazilla-list1" class="form-control" required>
                      <option value="">Select Upazila</option>
                    </select>
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Post Office</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <input type="text" name="p_p_office" class="form-control" required>
                  </div>
                </div>
                <!------------------------------------------->
                <div class="form-row form-group">
                  <label class="col-sm-5 col-form-label">Post Code</label>
                  <label class="col-form-label">:</label>
                  <div class="col">
                    <input type="text" name="p_p_code" class="form-control" required>
                  </div>
                </div>
                <!--------------------------------------------->
              </div>
            </div>
          </div>
        </div>
        <!-- report/last login part -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Reporting To</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="reporting_to" class="form-control">
          </div>
          <label class="col-sm-2 col-form-label">Last Login To</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="date" name="sa_last_login" class="form-control" placeholder="Passport No" required>
          </div>
        </div>
        <!-- driving tin  part -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Active Status</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <select name="active_status" id="" class="form-control">
              <option value="">---select---</option>
              <option value="1">Yes</option>
              <option value="0">No</option>
            </select>
          </div>
          <label class="col-sm-2 col-form-label">Sa Role No</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="sa_role_no" class="form-control">
          </div>
        </div>
        <!-- nid/pasport part -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">National ID No</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="number" name="nid" class="form-control" placeholder="Nationa ID No" required>
          </div>
          <label class="col-sm-2 col-form-label">Pasport</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="passport_no" class="form-control" placeholder="Passport No" required>
          </div>
        </div>
        <!-- driving tin  part -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Driving LC No</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="driving_lc_no" class="form-control" required>
          </div>
          <label class="col-sm-2 col-form-label">TIN No</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="tin_no" class="form-control">
          </div>
        </div>
        <!-- salary incriment date  part -->
        <div class="form-row form-group">
          <label class="col-sm-2 col-form-label">Next Incriment date</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="date" name="next_incr_date" class="form-control" required>
          </div>
          <label class="col-sm-2 col-form-label">m_status</label>
          <label class="col-form-label">:</label>
          <div class="col">
            <input type="text" name="m_status" class="form-control">
          </div>
        </div>
        


        <!-- ------------------------------------------------------------ -->
        <input type="submit" value="Submit" id="register" class=" btn btn-primary form-control text-center" name="SubBtn">
      </form>
      <!-- -------------------------------->
    </div>
  </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>
<!-- Page specific javascripts-->
<!-- registration_division_district_upazila_jquesr_script -->
<script>
  function getDistrict(val) {
    $.ajax({
      type: "POST",
      url: "getDistrict.php",
      data: 'division_id=' + val,
      success: function(data) {
        $("#district-list").html(data);
        getUpazilas();
      }
    });
  }

  function getUpazilas(val) {
    $.ajax({
      type: "POST",
      url: "getUpazilas.php",
      data: 'district_id=' + val,
      success: function(data) {
        $("#upazilla-list").html(data);
      }
    });
  }

  function getDistrict1(val) {
    $.ajax({
      type: "POST",
      url: "getDistrict.php",
      data: 'division_id=' + val,
      success: function(data) {
        $("#district-list1").html(data);
        getUpazilas1();
      }
    });
  }

  function getUpazilas1(val) {
    $.ajax({
      type: "POST",
      url: "getUpazilas.php",
      data: 'district_id=' + val,
      success: function(data) {
        $("#upazilla-list1").html(data);
      }
    });
  }
</script>
<script type="text/javascript">
  $(document).ready(function() {
    $("#common").addClass('active');
    $("#regform").addClass('active');
    $("#common").addClass('is-expanded');

  });
</script>

</body>

</html>