<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
  <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="../images/hasib.jpg" height="50px" width="50px" alt="User Image">

    <div>
      <p class="app-sidebar__user-name">Md. Hasibuzzaman</p>
      <p class="app-sidebar__user-designation">Backend Developer</p>
    </div>
  </div>
  <ul class="app-menu">
    <li>
      <a class="app-menu__item" id="dashboard" href="index.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a>
   </li>
    <!-- sample menu -->
    <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Employee Info</span><i class="treeview-indicator fa fa-angle-right"></i></a>
      <ul class="treeview-menu">
        <li><a class="treeview-item" href="../hr_emp/hr_emp.php"><i class="icon fa fa-circle-o"></i> Employee Reg.</a></li>
        <li><a class="treeview-item" href="../menu_role/user_roles_add.php"><i class="icon fa fa-circle-o"></i> User Role</a></li>
        <li><a class="treeview-item" href="../menu_role/user_roles_details.php"><i class="icon fa fa-circle-o"></i> User Role Details</a></li>
        <li><a class="treeview-item" href="../menu_role/user_grand_roles.php"><i class="icon fa fa-circle-o"></i> User Grand Role</a></li>
        <li><a class="treeview-item" href="../menu_role/user_menu.php"><i class="icon fa fa-circle-o"></i> user menu</a></li>
        <li><a class="treeview-item" href="../menu_role/user_sub_menu.php"><i class="icon fa fa-circle-o"></i> user sub menu</a></li>
        <li><a class="treeview-item" href="../menu_role/sm_roledtl.php"><i class="icon fa fa-circle-o"></i> Role_details</a></li>
        <li><a class="treeview-item" href="../menu_role/user_create.php"><i class="icon fa fa-circle-o"></i> User Create </a></li>
      </ul>
    </li>
    <!-- holdiday setup  -->
    <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Holiday Setup</span><i class="treeview-indicator fa fa-angle-right"></i></a>
      <ul class="treeview-menu">
        <li><a class="treeview-item" href="../holiday/ho_holiday.php"><i class="icon fa fa-circle-o"></i> Holiday Setup</a></li>
      </ul>
    </li>
    <!-- Organization Management  -->
    <li><a class="app-menu__item" id="dashboard" href="../organization/organization.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Organization Management</span></a></li>

    <!-- single page  -->
    <!-- <li><a class="treeview-item" href="blank-page.php"><i class="icon fa fa-circle-o"></i> Blank Page</a></li>
            <li><a class="treeview-item" href="page-login.php"><i class="icon fa fa-circle-o"></i> Login Page</a></li>
            <li><a class="treeview-item" href="page-lockscreen.php"><i class="icon fa fa-circle-o"></i> Lockscreen Page</a></li>
            <li><a class="treeview-item" href="page-user.php"><i class="icon fa fa-circle-o"></i> User Page</a></li>
            <li><a class="treeview-item" href="page-invoice.php"><i class="icon fa fa-circle-o"></i> Invoice Page</a></li>
            <li><a class="treeview-item" href="page-calendar.php"><i class="icon fa fa-circle-o"></i> Calendar Page</a></li>
            <li><a class="treeview-item" href="page-mailbox.php"><i class="icon fa fa-circle-o"></i> Mailbox</a></li>
            <li><a class="treeview-item" href="page-error.php"><i class="icon fa fa-circle-o"></i> Error Page</a></li>
          </ul>
        </li> -->
  </ul>
</aside>