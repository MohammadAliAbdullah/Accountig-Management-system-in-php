<?php
session_start();
require "../database.php";
?>

<?php
//insrt query
if (isset($_POST['subBtn'])) {
    $emp_n = $_SESSION['emp_no'];
    $office_code = $_SESSION['office_code'];
    $bank_acc_no = $_POST['bank_acc_no'];
    $acc_name = $_POST['acc_name'];
    $bank_code = $_POST['bank_code'];
    $bank_name = $_POST['bank_name'];
    $branch_code = $_POST['branch_code'];
    $branch_name = $_POST['branch_name'];
    $bank_address = $_POST['bank_address'];
    $general_acc_code = $_POST['gl_acc_code'];
    $insertQuery = "INSERT INTO `bank_acc_info` (`office_code`, `bank_acc_no`,`acc_name`, `bank_code`,`bank_name`,`branch_code`,`branch_name`,`bank_address`,`gl_acc_code`,`ss_creator`) VALUES ('$office_code','$bank_acc_no','$acc_name','$bank_code','$bank_name','$branch_code','$branch_name','$bank_address','$general_acc_code',' $emp_n')";
    $conn->query($insertQuery);
    // echo $insertQuery; exit;
    if ($conn->affected_rows == 1) {

        echo "<script>alert('Save Successfully')</script>";
    } else {
        // $message = "Save Invalid !!";
        echo "<script>alert('Save Invalid !!')</script>";
    }

    // $insertQuery = "INSERT INTO `bank_chq_leaf_info` (`office_code`,`bank_code`,`account_no`,`beg_chq_no`,`chq_leaf_no`,`status_date`,`ss_creator`) VALUES ('$office_code','$bank_code','$branck_code','$account_no','$beg_chq_no','$chq_leaf_no','$status_date',' $emp_n')";
    // $conn->query($insertQuery);
    // // echo $insertQuery; exit;
    // if ($conn->affected_rows == 1) {

    //     echo "<script>alert('Save Successfully')</script>";
    // } else {
    //     // $message = "Save Invalid !!";
    //     echo "<script>alert('Save Invalid !!')</script>";
    // }





    header("Location:bank_acc_info.php");
}
?>
<?php
$query = "Select Max(acc_code) From gl_acc_code where acc_level=1";
$returnDrow = mysqli_query($conn, $query);
$resultrow = mysqli_fetch_assoc($returnDrow);
$maxRowsrow = $resultrow['Max(acc_code)'];
if (empty($maxRowsrow)) {
    $lastRowrow = $maxRowsrow = 100000000000;
} else {
    $lastRowrow = $maxRowsrow + 100000000000;
} //

?>

<?php
require "../source/top.php";
?>
<style>
    .maingltable {
        border-style: solid;
        border-width: 5px;
    }

    .maingl {
        clear: both;
        height: 50px;
        width: 100%
    }

    .leftgl {
        float: left;
        width: 33%;
    }

    .meddlegl {
        float: left;
        width: 33%
    }

    .rightgl {
        float: right;
        width: 33%
    }

    @media screen and (max-width: 800px) {

        .leftgl,
        .meddlegl,
        .rightgl {
            width: 100%;
            text-align: center;
        }
    }

    @media screen and (max-width: 500px) {

        .leftgl,
        .meddlegl,
        .rightgl {
            width: 100%;
            text-align: center;

        }
    }
</style>
<?php
require "../source/header.php";
?>
<?php
require "../source/sidebar.php";
?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Bank Account Information </h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">

            <!-- ----------------code here---------------->
            <!-- top start  -->
            <div class="maingltable">
                <br>
                <div class="container">
                    <div class="maingl">
                        <div class="leftgl">
                            <p>Logo. Organigation Name</p>
                            <p>System Name</p>
                        </div>
                        <div class="meddlegl">
                            <h4>Bank Account Information</h4>
                        </div>
                        <div class="rightgl">
                            <p>Process Month And Year:..-07-2019</p>
                            <p>User:xxxxxxxxxx</p>
                        </div>
                    </div>
                    <hr>
                    <div style="padding:20px;">
                        <!-- form start  -->
                        <form method="post">
                            <!-- Office Code -->
                            <div class="form-group row">
                                <!-- <label class="col-sm-2 col-form-label">Office Code</label> -->
                                <div class="col-sm-6">
                                    <!-- <input type="text" name="office_code" class="form-control" required autofocus value=<?php if (!empty($lastRowrow)) {
                                                                                                                                    echo $lastRowrow;
                                                                                                                                } ?>> -->
                                </div>
                            </div>
                            <!-- Bank Account No. -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Bank Account No.</label>
                                <div class="col-sm-6">
                                    <input type="text" name="bank_acc_no" class="form-control" id="" placeholder="Bank Account No" required>
                                </div>
                            </div>
                              <!-- Account Name -->
                              <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Account Name</label>
                                <div class="col-sm-6">
                                    <input type="text" name="acc_name" class="form-control" id="" placeholder="Account Name" required>
                                </div>
                            </div>
                            <!-- Bank Code  -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Bank</label>
                                <div class="col-sm-6">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <input type="text" name="bank_code" class="form-control" id="" placeholder="Bank Code" required>
                                        </div>
                                        <div class="col-sm-8">
                                            <input type="text" name="bank_name" class="form-control" id="" placeholder="Bank Name" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Branch name  -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Branch</label>
                                <div class="col-sm-6">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <input type="text" name="branch_code" class="form-control" id="" placeholder="Branch Code" required>
                                        </div>
                                        <div class="col-sm-8">
                                            <input type="text" name="branch_name" class="form-control" id="" placeholder="Branch Name" required>
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <!-- Bank Address  -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Bank Address </label>
                                <div class="col-sm-6">
                                    <input type="text" name="bank_address" class="form-control" id="" placeholder="Bank Address" required>
                                </div>
                            </div>
                            <!-- General Account Code  -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">General Account Name</label>
                                <div class="col-sm-6">
                                    <select name="gl_acc_code" class="form-control select2" required>
                                        <option value="">-Select Account Name-</option>
                                        <?php
                                        require '../database.php';
                                        $selectQuery = "SELECT * FROM `gl_acc_code` where postable_acc= 'Y' AND acc_type=2 ORDER by acc_code";
                                        
                                        $selectQueryResult = $conn->query($selectQuery);
                                        if ($selectQueryResult->num_rows) {
                                            while ($row = $selectQueryResult->fetch_assoc()) {
                                                ?>
                                        <?php
                                                echo '<option value="' . $row['acc_code'] . '">' . $row['acc_head'] . '</option>';
                                            }
                                    
                                        }
                                        ?>
                                    </select>


                                    <!-- <input type="text" name="gl_acc_code" class="form-control" id="coding_language" placeholder="General Account Code" required> -->
                                </div>
                            </div>

                            <!-- submit  -->
                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <input type="submit" class="btn btn-primary" name="subBtn" value="submit">
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- form close  -->
                    <!-- table view start  -->
                    <div class="table-responsive border-dark border-top">
                        <table class="table table-hover">
                            <tr class="active">
                                <th>Office Code</th>
                                <th>Bank Account No</th>
                                <th>Account Name</th>
                                <th>Bank Code </th>
                                <th>Bank Name</th>
                                <th>Bank Address</th>
                                <th>General Account Code </th>
                                <th>Creator</th>
                                <th>Action</th>
                            </tr>
                            <?php
                            $sql = "SELECT * FROM bank_acc_info";
                            $query = $conn->query($sql);
                            while ($rows = $query->fetch_assoc()) {


                                echo
                                    "<tr>
									<td>" . $rows['office_code'] . "</td>
									<td>" . $rows['bank_acc_no'] . "</td>
									<td>" . $rows['acc_name'] . "</td>
									<td>" . $rows['bank_code'] . "</td>
									<td>" . $rows['bank_name'] . "</td>
									<td>" . $rows['bank_address'] . "</td>
									<td>" . $rows['gl_acc_code'] . "</td>
									<td>" . $rows['ss_creator'] . "</td>
                                    <td>
                                    <a href='bank_acc_info_edit.php?recortid=" . $rows['bank_acc_no'] . "' class='btn btn-success btn-sm><span class='glyphicon glyphicon-edit'></span>Edit</a>
									<a href='#delete_" . $rows['bank_acc_no'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
									</td>
								</tr>";
                                // include('edit_delete_modal.php');
                            }
                            ?>
                        </table>
                    </div>
                    <!-- table view end -->
                </div>
                <!-- ----------------code here---------------->
            </div>
        </div>
</main>


<script type="text/javascript">
    $(function() {
        $("#coding_language").autocomplete({
            source: '../database.php'

        });

    });
</script>


<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The java../jcript plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>
<!-- registration_division_district_upazila_jqu_script -->

<script src="../js/select2.full.min.js"></script>

<script>
$(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
   
  })
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#accinfo").addClass('active');
        $("#gl_acc").addClass('active');
        $("#accinfo").addClass('is-expanded');
    });
</script>

<?php
$conn->close();
?>
</body>

</html>