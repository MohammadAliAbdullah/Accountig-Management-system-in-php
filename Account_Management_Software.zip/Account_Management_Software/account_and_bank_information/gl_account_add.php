<?php
 session_start();
?>
<?php
require "../database.php";
?>
<?php
//update query
if (isset($_POST['subBtn'])) {
  $acc_code = $_POST['acc_code'];
  $acc_head = $_POST['acc_head'];
  $postable_acc = $_POST['postable_acc'];
  $rep_glcode = $_POST['rep_glcode'];
  $category_code = $_POST['category_code'];
  $parent_acc_code = $_POST['parent_acc_code'];
  $acc_level = $_POST['acc_level'];
  $acc_type= $_POST['acc_type'];



  $insertQuery = "INSERT INTO `gl_acc_code` (`id`, `acc_code`, `acc_head`,`acc_level`,`acc_type`, `postable_acc`,`rep_glcode`,`category_code`,`parent_acc_code`,`ss_creator_on`) VALUES (NULL,'$acc_code','$acc_head','$acc_level','$acc_type','$postable_acc','$rep_glcode','$category_code','$parent_acc_code',now())";


  $conn->query($insertQuery);
  // echo $insertQuery; exit;
  if ($conn->affected_rows == 1) {
    $message = "Save Successfully";
  }
  $conn->close();
  header("Location:gl_account.php");
}
//select query start
if (isset($_GET['id'])) {
  $selectQuery = "select * from gl_acc_code where id='" . $_GET['id'] . "'";
  //echo "$selectQuery";
  //exit;
  $selectQueryReuslt = $conn->query($selectQuery);
  $row = $selectQueryReuslt->fetch_assoc();
  // var_dump($row);
}
// $selectQueryReuslt->free();
?>
<?php
$selectQuery = "SELECT * FROM `gl_acc_code`";
$selectQueryResult = $conn->query($selectQuery);
if ($selectQueryResult->num_rows) {
  while ($rowss = $selectQueryResult->fetch_array()) {
    ?>
    <?php

        if ($row['id'] != $rowss['parent_acc_code']) {
          if ($row['acc_level'] == 1) {
            $lastRow = $row['acc_code'] + 1000000000;
          } elseif ($row['acc_level'] == 2) {
            $lastRow = $row['acc_code'] + 10000000;
          } elseif ($row['acc_level'] == 3) {
            $lastRow = $row['acc_code'] + 100000;
          } elseif ($row['acc_level'] == 4) {
            $lastRow = $row['acc_code'] + 1000;
          } elseif ($row['acc_level'] == 5) {
            $lastRow = $row['acc_code'] + 10;
          }
        } else {
          $query = "Select Max(acc_code) From gl_acc_code where $row[id]=parent_acc_code";
          $returnD = mysqli_query($conn, $query);
          $result = mysqli_fetch_assoc($returnD);
          $maxRows = $result['Max(acc_code)'];
          if ($row['acc_level'] == 1) {
            $lastRow = $maxRows + 1000000000;
          } elseif ($row['acc_level'] == 2) {
            $lastRow = $maxRows + 10000000;
          } elseif ($row['acc_level'] == 3) {
            $lastRow = $maxRows + 100000;
          } elseif ($row['acc_level'] == 4) {
            $lastRow = $maxRows + 1000;
          } elseif ($row['acc_level'] == 5) {
            $lastRow = $maxRows + 10;
          }
        }
        ?>
<?php
  }
}
?>
<?php
$maxRows1 = $row['acc_level'];
if (empty($maxRows1)) {
  $lastRows = $maxRows1 = 1;
} else {
  $lastRows = $maxRows1 + 1;
}
?>
<?php
require "../source/top.php";
?>
<?php
require "../source/header.php";
?>
<?php
require "../source/sidebar.php";
?>
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i>GL Account Add</h1>
    </div>

    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <!-- form start  -->
      <form action="" method="post">
        <!-- uner account -->
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Sub Account Under</label>
          <div class="col-sm-6">
            <input type="text" name="acc_code" class="form-control" value="<?php echo $row['acc_head']?>" readonly>
          </div>
        </div>
        <!-- acc conde  -->
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Account Code</label>
          <div class="col-sm-6">
            <input type="text" name="acc_code" class="form-control" autofocus value=<?php echo $lastRow; ?> readonly>
          </div>
        </div>
        <!-- account name  -->
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Account Name</label>
          <div class="col-sm-6">
            <input type="text" class="form-control" id="" name="acc_head" required>
          </div>
        </div>
        <!-- post able account  -->
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Post able Account <br>&lpar;Ladger/Group Acc&rpar;</label>
          <div class="col-sm-6">
            <select name="postable_acc" class="form-control">
              <option value="">Select</option>
              <option value="Y">Yes</option>
              <option value="N">No</option>
            </select>
          </div>
        </div>
        <!-- reporting  -->
        <div class="form-group row">
          <label class="col-sm-2 col-form-label">Reporting GL Code</label>
          <div class="col-sm-6">
            <input type="text" class="form-control" id="" name="rep_glcode">
          </div>
        </div>
        <!-- category  hidden but input value by catagory-->
          <select name="category_code" id="" class="form-control" hidden>
                  <!-- ----------------------------------->
                  <?php
          $selectQuery = 'SELECT * FROM `code_master` WHERE `hardcode`= "acat" AND `softcode`>0';
          $selectQueryResult =  $conn->query($selectQuery);		 
          if($selectQueryResult->num_rows){
              while($rows = $selectQueryResult->fetch_assoc()){
                ?>
                  <option value="<?php echo $rows['softcode']; ?>" <?php if($row['category_code']==$rows['softcode']){echo "selected";} ?>><?php  echo $rows['description']; ?></option>
                  <?php           
                    }
                  }
        ?>
                </select>
                <!-- Account Type  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Account Type</label>
              <div class="col-sm-6">
                <select name="acc_type" id="" class="form-control" required>
                  <!-- ----------------------------------->
                  <?php
                  $selectQuery = 'SELECT * FROM `code_master` WHERE `hardcode`= "acc_t" AND `softcode`>0';
                  $selectQueryResult =  $conn->query($selectQuery);
                  if ($selectQueryResult->num_rows) {
                    while ($row = $selectQueryResult->fetch_assoc()) {
                      echo '<option value="' . $row['softcode'] . '">'  . $row['description'] . '</option>';
                    }
                  }
                  ?>
                </select>
              </div>
            </div>
        <!-- hidden parant account code and account level set up-->
        <input type="number" class="form-control" name="parent_acc_code" value="<?php echo $row['id']; ?>" hidden>
        <input type="text" name="acc_level" class="form-control" required autofocus placeholder="ID" value=<?php if (!empty($lastRows)) {echo $lastRows;} ?> hidden>

        <!-- submit  -->
        <div class="form-group row">
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary" name="subBtn">Submit</button>
          </div>
        </div>
      </form>
    </div>
    <!-- form close  -->
    <!-- -------------------------------->
  </div>
  </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>


<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The java../jcript plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>

<!-- registration_division_district_upazila_jqu_script -->
<script type="text/javascript">
  $(document).ready(function() {
    $("#301000").addClass('active');
    $("#300000").addClass('active');
    $("#300000").addClass('is-expanded');
  });
</script>
<?php
$conn->close();
?>
</body>

</html>