<?php
  require "post_process.php";
  require "../source/top.php";
?>
<link rel="stylesheet" href="../css/oms.css">
<link rel="stylesheet" href="../css/hover-min.css">
<?php
  require "../source/header.php";
  require "../source/sidebar.php";
?>

<main class="app-content">
  <Section id="section-org">
  <form action="post_process.php" method="post" enctype="multipart/form-data">
  <div class="org">
    <div class="row">
      <div class="col-8">
        <div class="form__group">
          <input type="text" class="form__input" name="name" id="name" placeholder="Organization Name" autocomplete="off">
          <label for="name" class="form__label" autocomplete="off">Organization Name</label>
        </div>
        <div class="form__group">
          <input type="text" class="form__input" name="slogan" id="slogan" placeholder="Organization Slogan" autocomplete="off">
          <label for="name" class="form__label" autocomplete="off">Organization Slogan</label>
        </div>
      </div>
      <div class="col-4 ">
        <div class="form__profile">
          <img src="../images/profile-icon-9.png" id="profileImage" onclick="triggerClick()" class="form__logo"/>
          <input type="file" name="profiler" id="profile" onchange="displayImage(this)" style="display:none">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="form__group">
          <input type="text" class="form__input" name="address1" id="address1" placeholder="Address-1" autocomplete="off" autocomplete="off">
          <label for="name" class="form__label">Address-1</label>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="form__group">
          <input type="text" class="form__input" name="address2" id="address2" placeholder="Address-2" autocomplete="off">
          <label for="name" class="form__label">Address-2</label>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-6">
        <div class="form__group">
          <input type="email" class="form__input" name="email" id="email" placeholder="Email Address" autocomplete="off">
          <label for="name" class="form__label">Email Address</label>
        </div>
      </div>
      <div class="col-6">
        <div class="form__group">
          <input type="text" class="form__input" name="telephone" id="telephone" pattern="[0-9]+"  placeholder="Telephone No" autocomplete="off">
          <label for="name" class="form__label">Telephone No</label>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-4">
          <div class="form__group">
            <input type="text" class="form__input" name="fax" id="fax" placeholder="Fax No" autocomplete="off">
            <label for="name" class="form__label">Fax No</label>
          </div>
        </div>
      <div class="col-4">
        <div class="form__group">
          <input type="text" class="form__input" name="website" id="website" placeholder="Website" autocomplete="off">
          <label for="name" class="form__label">Website</label>
        </div>
      </div>
      <div class="col-4">
        <div class="form__group">
          <input type="text" class="form__input" name="country" id="country" placeholder="Country" autocomplete="off">
          <label for="name" class="form__label">Country</label>
        </div>
      </div>
    </div>
</div>   
<!-- fincancial   -->
<div class="org">
  <div class="row">
    <div class="col-3">
      <div class="form__group">
        <input type="number" class="form__input" name="fmStart" max="12" min="1" id="fmStart" placeholder="Financial Month Start" autocomplete="off">
        <label for="name" class="form__label">Financial Month Start</label>
      </div>
    </div>
    <div class="col-3">
      <div class="form__group">
        <input type="text" class="form__input" name="fyStart" id="fyStart" placeholder="Financial Year Start" onfocus="(this.type='date')" onblur="dateFormatChanger(this)">
        <label for="name" class="form__label">Financial Year Start</label>
      </div>
    </div>
    <div class="col-3">
      <div class="form__group">
        <input type="text" class="form__input" name="locCurr" id="locCurr" placeholder="Local Currency Name" autocomplete="off">
        <label for="name" class="form__label">Local Currency Name</label>
      </div>
    </div>
    <div class="col-3">
      <div class="form__group">
        <input type="text" class="form__input" name="locCurrSym" id="locCurrSym" placeholder="Local Currency Symbol" autocomplete="off">
        <label for="name" class="form__label">Local Currency Symbol</label>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-6">
      <div class="form__group">
      <input type="number" class="form__input" name="fmEnd" max="12" min="1" id="fmEnd" placeholder="Financial Month End" autocomplete="off">
      <label for="name" class="form__label">Financial Month End</label>
      </div>
    </div>
    <!-- <div class="col-3">
      <div class="form__group">
        <input type="text" class="form__input" name="fyEnd" id="fyEnd" placeholder="Financial Year End" onfocus="(this.type='date')" onblur="(this.type='text')">
        <label for="name" class="form__label">Financial Year End</label>
      </div>
    </div> -->
    <div class="col-3">
      <div class="form__group">
        <input type="text" class="form__input" name="forCurr" id="forCurr" placeholder="Foreign Currency Name" autocomplete="off">
        <label for="name" class="form__label">Foreign Currency Name</label>
      </div>
    </div>
    <div class="col-3">
      <div class="form__group">
        <input type="text" class="form__input" name="forCurrSym" id="forCurrSym" placeholder="Foreign Currency Symbol" autocomplete="off">
        <label for="name" class="form__label">Foreign Currency Symbol</label>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-6">
      <div class="form__group">
        <input type="text" class="form__input" name="budget" id="budget" placeholder="Budget Year" autocomplete="off">
        <label for="name" class="form__label">Budget Year</label>
      </div>
    </div>
    <div class="col-6">
      <div class="form__group">
        <input type="text" class="form__input" name="noOfDec" id="noOfDec" placeholder="No Of Decimal" autocomplete="off">
        <label for="name" class="form__label">No Of Decimal</label>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-6">
      <div class="form__group">
        <div class="form__radio-group">
          <label class="form__radio-title">Inventory Maintenance</label>
          <input type="radio" class="form__radio-input" id="yesInventory" value="yes" name="inventory">
          <label for="yesInventory" class="form__radio-label">
            <span class="form__radio-btn"></span>
            Yes
          </label>
        </div>
        <div class="form__radio-group">
          <input type="radio" class="form__radio-input" id="noInventory" value="no" name="inventory">
          <label for="noInventory" class="form__radio-label">
            <span class="form__radio-btn"></span>
            No
          </label>
        </div>

      </div>
      <div class="form__group">
        <div class="form__radio-group">
          <label class="form__radio-title">Round Decimal</label>

          <input type="radio" class="form__radio-input" onchange="roundManipulationOn(this)" id="yesRound" value="yes" name="round">
          <label for="yesRound" class="form__radio-label">
            <span class="form__radio-btn"></span>
            Yes
          </label>
        </div>
        <div class="form__radio-group">
          <input type="radio" class="form__radio-input" onchange="roundManipulationOff(this)" id="noRound" value="no" name="round">
          <label for="noRound" class="form__radio-label">
            <span class="form__radio-btn"></span>
            No
          </label>
        </div>

      </div>
    </div>
    <div class="col-6">
      <div class="form__group" style="margin-bottom:30px">
        <select class="form__input" name="imgType" id="imgType">
          <option value="" disabled selected>Image Type</option>
          <option value=".jpg">.jpg</option>
          <option value=".jpeg">.jpeg</option>
          <option value=".png">.png</option>
          <option value=".svg">.svg</option>
        </select>
      </div>
      <div class="form__group">
        <input type="text" class="form__input" name="imgPath" id="imgPath" placeholder="Image Path" autocomplete="off">
        <label for="imgPath" class="form__label" autocomplete="off">Image Path</label>
      </div>
      <div class="form__group">
        <select class="form__input" name="roundType" id="roundType">
          <option value="" disabled selected>Rounding Type</option>
          <option value="Upper">Upper</option>
          <option value="Normal">Normal</option>
          <option value="Down">Down</option>
        </select>
      </div>
    </div>
  </div>
</div>
<!-- other  -->

      <div class="u-center">
        <input type="submit" name="enter" value="Submit" class="org__btn">
      </div>
    </form>
  </Section>
</main>

<script src="../js/profile.js"></script>
<?php require_once "../source/footer.php"; ?>