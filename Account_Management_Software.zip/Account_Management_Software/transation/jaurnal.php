<!-- ------------------------------
###################################
###     Create: Hasibuzzaman    ###
###     Date: 27-11-2019 to        ###
###     Mob: 01738356180        ###
###################################
----------------------------------->
<?php
session_start();
?>

<?php

if (isset($_POST['subBtn'])) {
    require "../database.php";
    // $trn_no = $_POST['trn_no'];
    $office_code = $_POST['office_code'];
    $year_code = $_POST['year_code'];
    $batch_no = $_POST['batch_no'];
    $tran_date = $_POST['tran_date'];
    $by_account = $_POST['by_account'];
    $toaccount = $_POST['toaccount'];
    $tran_mode = $_POST['tran_mode'];
    if(empty($_POST['craccount'])){
        $vaucher_type=$_POST['vtcr'];}
        else{
            $vaucher_type = $_POST['vtdr'];
        }
    $draccount = $_POST['draccount'];
    $craccount = $_POST['craccount'];
    $particular = $_POST['particular'];
    // $draccount1 = $_POST['draccount1'];
    // $craccount1 = $_POST['craccount1'];
    // $particular1 = $_POST['particular1'];
    if(empty($_POST['draccount1'])){
        $vaucher_type1=$_POST['vtdr'];}
        else{
            $vaucher_type1 = $_POST['vtcr'];
        }
    $ss_creator = $_POST['ss_creator'];
    $ss_org_no = $_POST['ss_org_no'];


    // $insertQuery = "INSERT INTO `tran_details` (`tran_no`,`office_code`,`year_code`,`batch_no`, `tran_date`, `gl_acc_code`,`tran_mode`,`vaucher_type`, `description`, `dr_amt_loc`,`cr_amt_loc`,`ss_creator`,`ss_creator_on`,`ss_org_no`) VALUES (NULL,'$office_code','$year_code','$batch_no','$tran_date','$by_account','$tran_mode','$vaucher_type1','$particular','$draccount','$craccount','$ss_creator',now(),'$ss_org_no')";

    // $conn->query($insertQuery);
    // // echo $insertQuery;
    // if ($conn->affected_rows == 1) {
    //     $message = "Dr Save Successfully";
    // }
    
     
    // insert cr 


    $rol = $_POST['role_no'];
  for ($count = 0; $count < count($rol); ++$count) {
    $role_no = $_POST['role_no'][$count];
    $menu_no = $_POST['menu_no'][$count];
    $role = $_POST['emp_no'][$count];

    $insertQuery2 = "INSERT INTO `tran_details` (gl_acc_code, dr_amt_loc, cr_amt_loc) VALUES('$role_no','$menu_no','$role')";
    echo $insertQuery2;
    $conn->query($insertQuery2);
    if ($conn->affected_rows == count($rol)) {
        $messagecr = "cr Save Successfully";
    } 
  }



    // $insertQuery = "INSERT INTO `tran_details` (`tran_no`,`office_code`,`year_code`,`batch_no`, `tran_date`, `gl_acc_code`,`tran_mode`,`vaucher_type`, `description`,`dr_amt_loc`, `cr_amt_loc`,`ss_creator`,`ss_creator_on`,`ss_org_no`) VALUES (NULL,'$office_code','$year_code','$batch_no','$tran_date','$toaccount','$tran_mode','$vaucher_type','$particular1','$draccount1','$craccount1','$ss_creator',now(),'$ss_org_no')";
    // $conn->query($insertQuery);
    // // echo $insertQuery;
    // if ($conn->affected_rows == 1) {
    //     $messagecr = "cr Save Successfully";
    // }
}
?>
<?php
require "../source/top.php";
require "../source/header.php";
require "../source/sidebar.php";
?>
<main class="app-content">
    <div class="app-title">
    <div>
            <h1><i class="fa fa-dashboard"></i>Cash Receipt</h1>
            <?php if (isset($message)) echo $message; ?>
            <?php if (isset($messagecr)) echo $messagecr; ?>
            <?php if (isset($messages)) echo $messages; ?>
            <?php if (isset($messagescr)) echo $messages; ?>

        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
        </ul>
    </div>
    <div class="row">
        <!-- ----------------code here---------------->
        <div class="c_main">

            <!-- head -->
            <div class="c_head">
                <!-- form start  -->
                <form method="post">
                    <div class="c_main_left"><br>
                        <div class="org_row org_group">
                            <label class="org_4 org_label">Receipt Voucher No</label>
                            <div class="org_8">
                                <!-- <input type="text" name="trn_no" readonly class="org_8 org_label" required autofocus > -->
                            </div>
                            <label class="org_2 org_label">Received Type</label>
                            
                        </div>
                    </div>
                    <div class="c_main_right">
                        <div class="org_row org_group">
                            <label class="org_4 org_label">Transaction Date</label>
                            <div class="org_6">
                                <input type="date" name="tran_date" id="date" class="org_form">
                                <script>
                                    const dateInput = document.querySelector('#date');
                                    var date = new Date();
                                    var month = date.getMonth() + 1;
                                    if (month < 10) {
                                        month = `0${month}`;
                                    }
                                    var dateValue = `${date.getFullYear()}-${month}-${date.getDate()}`;
                                    dateInput.value = `${dateValue}`;
                                </script>
                            </div>
                        </div>
                        <div class="org_row org_group">
                            <label class="org_4 org_label">User ID</label>
                            <div class="org_6">
                                <?php if (isset($_SESSION['username'])) : ?>
                                    <input type="text" name="ss_creator" id="" value="<?php echo $_SESSION['username']; ?>" class="org_form" readonly>
                                <?php endif; ?>


                            </div>
                        </div>

                    </div>
            </div>
            <!-- head close  -->
            <!-- maid body start  -->
            <!-- 1st section  -->
            <div class="c_form_div">
                <div class="form-row" style="width:98%">
                    <div class="form-group col-md-3">
                        <label>By Account</label>
                        <select class="form-control select2" name="by_account" required>
                            <option value="">---Select---</option>
                            <?php
                            $selectQuery = "SELECT * FROM `gl_acc_code` where postable_acc= 'Y' ORDER by acc_code";
                            $selectQueryResult =  $conn->query($selectQuery);
                            if ($selectQueryResult->num_rows) {
                                while ($row = $selectQueryResult->fetch_assoc()) {
                                    echo '<option value="' . $row['acc_code'] . '">'  . $row['acc_head'] . '</option>';
                                }
                            }
                            ?>
                        </select>

                    </div>
                    <div class="form-group col-md-3">
                        <label for="inputPassword4">Particular</label>
                        <input type="text" class="form-control" name="particular">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="inputPassword4">Dr. Amount</label>
                        <input type="text" class="form-control" name="draccount">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="inputPassword4">Cr. Amount</label>
                        <input type="text" class="form-control" name="craccount">
                    </div>
                </div>
            </div>
            <hr>
            <!-- 2nd section  -->
            <div class="c_form_div">
                <div class="form-row" style="width:98%">
                <table class="table" id="multi_table" width="95%">
        <tr>
          <th width="30%">role_no</th>
          <th width="20%">menu_no</th>
          <th width="45%">emp_no</th>
          <th width="5%"></th>
        </tr>
        <tr>
          <td><input type="text" name="role_no[]"></td>
          <td><input type="text" name="menu_no[]"></td>
          <td><input type="text" name="emp_no[]"></td>
          <td></td>
        </tr>
      </table>
      <div align="right">
        <button type="button" name="add" id="add" class="btn btn-success btn-xl">+</button>
      </div>
      
                </div>
            </div>
             <!-- hidden  -->
             <input type="hidden" class="form-control" name="tran_mode" value="JR">
            <input type="hidden" class="form-control" name="office_code" value="<?php echo $_SESSION['office_code']; ?>">
            <input type="hidden" class="form-control" name="year_code" value="<?php echo $_SESSION['org_fin_year_st']; ?>">
            <input type="hidden" class="form-control" name="vtdr" value="DR">
            <input type="hidden" class="form-control" name="vtcr" value="CR">
            <input type="hidden" class="form-control" name="ss_org_no" value="<?php echo $_SESSION['org_no']; ?>">
            <!-- batch_no -->
            <?php
            $querys = "Select Max(batch_no) From tran_details";
            $returns = mysqli_query($conn, $querys);
            $results = mysqli_fetch_assoc($returns);
            $maxRows = $results['Max(batch_no)'];
            if (empty($maxRows)) {
                $lastRows = $maxRows = 2019000000;
            } else {
                $lastRows = $maxRows + 1;
            }
            ?>
            <input type="text" name="batch_no" readonly class="org_8 org_label" required autofocus placeholder="ID" value="<?php if (!empty($lastRows)) {
                                                                                                                                echo $lastRows;
                                                                                                                            } ?>" hidden>

            <!-- /////////////////////////////////////  -->
            <div class="text-right" style="margin-right:20px">
                <input type="submit" value="Submit" name="subBtn" class="btn btn-success">
                <!-- <input type="submit" value="Cancel" name="cacel" class="btn btn-danger"> -->
            </div>

            </form>
            <!-- form end  -->
        </div> 
        <!-- ----------------code here---------------->
    </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The java script plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>
<!-- registration_division_district_upazila_jqu_script -->
<script src="../js/select2.full.min.js"></script>

<script>
    $(function() {
        //Initialize Select2 Elements
        $('.select2').select2()

    })
</script>
<script>
    $(document).ready(function() {
        $("#406000").addClass('active');
        $("#400000").addClass('active');
        $("#400000").addClass('is-expanded');
    });
</script>
<script>
  $(document).ready(function() {

    var count = 1;
    $('#add').click(function() {
      count = count + 1;
      var html_code = "<tr id='row" + count + "'>";
      html_code += "<td><input type='text' name='role_no[]'></td>";
      html_code += "<td><input type='text' name='menu_no[]'></td>";
      html_code += "<td><input type='text' name='emp_no[]'></td>";
      html_code += "<td><button type='button' name='remove' data-row='row" + count + "' class='btn btn-danger btn-xs remove'>-</button></td>";
      html_code += "</tr>";
      //  alert(html_code);
      $('#multi_table').append(html_code);
    });
    $(document).on('click', '.remove', function() {
      var delete_row = $(this).data("row");
      // alert(delete_row);
      $('#' + delete_row).remove();
    });


    // =========================================


    var count = 0;
    $(document).on('click', '.add', function() {
      // alert("add button");
      count++;
      var html = '';
      // alert (html);
      html += '<td></td>';
      html += '<td></td>';
      html += '<td></td>';
      html += '<td></td>';
      html += '<td></td>';
      html += '<td id="www">Remove</td>';
      $('tr').append(html);

    });
    $(document).on('click', '.ww', function() {
      $(this).closest('td').remove();
    });
  });
</script>

</body>

</html>
