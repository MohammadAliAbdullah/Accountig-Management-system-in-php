<?php
	session_start();
	include_once('../database.php');

	if(isset($_POST['add'])){
		$hardcode = $_POST['hardcode'];
		$softcode = $_POST['softcode'];
		$description = $_POST['description'];
		$sort_des = $_POST['sort_des'];
		$sql = "INSERT INTO `code_master` VALUES(NULL,'$hardcode','$softcode','$description','$sort_des','',now(),'',now())";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Record added successfully';
		}
		///////////////

		//use for MySQLi Procedural
		// if(mysqli_query($conn, $sql)){
		// 	$_SESSION['success'] = 'Member added successfully';
		// }
		//////////////
		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: code_master.php');
?>