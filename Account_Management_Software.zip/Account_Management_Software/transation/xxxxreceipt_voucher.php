<!-- ------------------------------
###################################
###     Create: Hasibuzzaman    ###
###     Date: 13-11-2019        ###
###     Mob: 01738356180        ###
###################################
----------------------------------->
<?php
session_start();
?>
<?php

if (isset($_POST['subBtn'])) {
    require "../database.php";
    // $trn_no = $_POST['trn_no'];
    $office_code = $_POST['office_code'];
    $year_code = $_POST['year_code'];
    $batch_no = $_POST['batch_no'];
    $tran_date = $_POST['tran_date'];
    $by_account = $_POST['by_account'];
    $toaccount = $_POST['toaccount'];
    $tran_mode = $_POST['tran_mode'];
    $vaucher_type = $_POST['vaucher_type'];
    $particular = $_POST['particular'];
    $craccount = $_POST['craccount'];
    $ss_creator = $_POST['ss_creator'];
    $ss_org_no = $_POST['ss_org_no'];


    $insertQuery = "INSERT INTO `tran_details` (`tran_no`,`office_code`,`year_code`,`batch_no`, `tran_date`, `gl_acc_code`,`tran_mode`,`vaucher_type`, `description`, `dr_amt_loc`,`ss_creator`,`ss_creator_on`,`ss_org_no`) VALUES (NULL,'$office_code','$year_code','$batch_no','$tran_date','$by_account','$tran_mode','$vaucher_type','$particular','$craccount','$ss_creator',now(),'$ss_org_no')";

    $conn->query($insertQuery);
    // echo $insertQuery; exit;
    if ($conn->affected_rows == 1) {
        $message = "Save Successfully";
    }
    // update dr 
    $updateQuery = "UPDATE `gl_acc_code` SET acc_bal_loc=acc_bal_loc-'$craccount' where acc_code='$by_account'";
    $conn->query($updateQuery);
    if ($conn->affected_rows == 1) {
        $messages = "Updated successfully";

        // header("Location:user_menu.php");
    }
    // insert cr 
    $insertQuery = "INSERT INTO `tran_details` (`tran_no`,`office_code`,`year_code`,`batch_no`, `tran_date`, `gl_acc_code`,`tran_mode`,`vaucher_type`, `description`, `cr_amt_loc`,`ss_creator`,`ss_creator_on`,`ss_org_no`) VALUES (NULL,'$office_code','$year_code','$batch_no','$tran_date','$toaccount','$tran_mode','$vaucher_type','$particular','$craccount','$ss_creator',now(),'$ss_org_no')";
    $conn->query($insertQuery);
    // echo $insertQuery; exit;
    if ($conn->affected_rows == 1) {
        $messagecr = "cr Save Successfully";
    }
    // update cr 
    $updateQuery = "UPDATE `gl_acc_code` SET acc_bal_loc=acc_bal_loc+'$craccount' where acc_code='$toaccount'";
    $conn->query($updateQuery);
    if ($conn->affected_rows == 1) {
        $messagescr = "Updated successfully";

        // header("Location:user_menu.php");
    }
}
?>

<?php
require "../source/top.php";
require "../source/header.php";
require "../source/sidebar.php";
?>
<style>
    .c_main {
        width: 100%;
        min-height: 600px;
        /* background-color: aqua; */
        border-style: solid;
        border-width: 5px;
        border-color: black;
        margin: 0 auto;

    }

    .c_head {
        border-bottom: 5px solid black;
        min-height: 100px;
    }

    .c_main_left,
    .c_body_h_left {
        width: 65%;
        float: left;
        margin-left: 20px;
        /* background-color: aqua;
            border-style: solid;
            border-width: 5px;
            border-color: black; */
    }

    .c_main_right,
    .c_body_h_right {
        width: 30%;
        float: right;
        margin-top: 5px;
        /* background-color: aqua;
            border-style: solid;
            border-width: 5px;
            border-color: black; */
    }

    .c_body {
        width: 100%;
        margin-top: 10px;
        background-color: rgb(149, 149, 229);
        height: 50px;
    }

    .c_form_div {
        width: 100%;
        margin-left: 20px;
    }

    /* for tab  */
    @media only screen and (max-width: 800px) {

        .c_main_left,
        .c_main_right,
        .c_body_h_left,
        .c_body_h_right {
            width: 100%;
            float: left;
            margin-left: 5px;
        }

        .c_head {
            height: 195px;
        }

        .c_body {
            height: 100px;
        }

        .c_form_div {
            width: 100%;
            margin: 10px;
        }
    }

    @media only screen and (max-width: 500px) {

        .c_main_left,
        .c_main_right,
        .c_body_h_left,
        .c_body_h_right {
            width: 100%;
            float: left;
            margin: 0 0 0 5px;
        }

        .c_head {
            height: 195px;
        }

        .c_body {
            height: 100px;
        }

        .c_form_div {
            width: 80%;
            margin-left: 10px;
            background-color: red;
        }

        .c_main {
            height: auto;
        }
    }
</style>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i>Cash Receipt</h1>
            <?php if (isset($message)) echo $message; ?>
            <?php if (isset($messagecr)) echo $messagecr; ?>
            <?php if (isset($messages)) echo $messages; ?>
            <?php if (isset($messagescr)) echo $messages; ?>

        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
        </ul>
    </div>
    <div class="row">
        <!-- ----------------code here---------------->
        <div class="c_main">

            <!-- head -->
            <div class="c_head">
                <!-- form start  -->
                <form method="post">
                    <div class="c_main_left"><br>
                        <div class="org_row org_group">
                            <label class="org_4 org_label">Receipt Voucher No</label>
                            <div class="org_6">
                                <!-- <input type="text" name="trn_no" readonly class="org_8 org_label" required autofocus > -->
                            </div>
                        </div>
                    </div>
                    <div class="c_main_right">
                        <div class="org_row org_group">
                            <label class="org_4 org_label">Transaction Date</label>
                            <div class="org_6">
                                <input type="date" name="tran_date" id="date" class="org_form">
                                <script>
                                    const dateInput = document.querySelector('#date');
                                    var date = new Date();
                                    var month = date.getMonth() + 1;
                                    if (month < 10) {
                                        month = `0${month}`;
                                    }
                                    var dateValue = `${date.getFullYear()}-${month}-${date.getDate()}`;
                                    dateInput.value = `${dateValue}`;
                                </script>
                            </div>
                        </div>
                        <div class="org_row org_group">
                            <label class="org_4 org_label">User ID</label>
                            <div class="org_6">
                                <?php if (isset($_SESSION['username'])) : ?>
                                    <input type="text" name="ss_creator" id="" value="<?php echo $_SESSION['username']; ?>" class="org_form" readonly>
                                <?php endif; ?>


                            </div>
                        </div>

                    </div>
            </div>
            <!-- head close  -->
            <?php
            require_once("../hr_emp/dbcontroller.php");
            $db_handle = new DBController();
            $query = "SELECT * FROM `gl_acc_code` where postable_acc= 'Y' ORDER by acc_code";
            $results = $db_handle->runQuery($query);
            ?>
            <!-- maid body start  -->
            <div class="c_body">
                <div class="c_body_h_left">
                    <div class="org_row org_group">
                        <label class="org_2 org_label">By Account</label>
                        <div class="org_4">
                            <select class="org_form select2" name="by_account" required id="division-list" onChange="getDistrict(this.value);">

                                <option value="">---Select---</option>

                                <?php
                                foreach ($results as $division) {
                                    ?>
                                    <option value="<?php echo $division["acc_code"]; ?>"><?php echo $division["acc_head"]; ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>

                        <label class="org_2 org_label" style="padding-left:10px;">By Account</label>
                        <div class="org_3">
                            <select class="org_form" name="by_account" required id="district-list" onChange="getUpazilas(this.value);">
                                <option value="">Select Distict</option>
                            </select>
                            

                        </div>
                    </div>
                </div>
                <div class="c_body_h_right">
                    <div class="org_row org_group">
                        <label class="org_4 org_label">A/C Balance</label>
                        <div class="org_6">
                            <input type="text" name="" id="" class="org_form" readonly>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <!-- 2nd section  -->
            <div class="c_form_div">
                <div class="form-row" style="width:98%">
                    <div class="form-group col-md-3">
                        <label>To Account</label>
                        <select class="form-control select2" name="toaccount" required>
                            <option value="">---Select---</option>
                            <?php
                            $selectQuery = "SELECT * FROM `gl_acc_code` where postable_acc= 'Y' ORDER by acc_code";
                            $selectQueryResult =  $conn->query($selectQuery);
                            if ($selectQueryResult->num_rows) {
                                while ($row = $selectQueryResult->fetch_assoc()) {
                                    echo '<option value="' . $row['acc_code'] . '">'  . $row['acc_head'] . '</option>';
                                }
                            }
                            ?>
                        </select>

                    </div>
                    <div class="form-group col-md-3">
                        <label for="inputPassword4">Particular</label>
                        <input type="text" class="form-control" name="particular">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="inputPassword4">Dr. Amount</label>
                        <input type="text" class="form-control" name="draccount" disabled>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="inputPassword4">Cr. Amount</label>
                        <input type="text" class="form-control" name="craccount">
                    </div>
                </div>
            </div>
            <!-- hidden  -->
            <input type="hidden" class="form-control" name="tran_mode" value="CR">
            <!-- batch_no -->
            <?php
            $querys = "Select Max(batch_no) From tran_details";
            $returns = mysqli_query($conn, $querys);
            $results = mysqli_fetch_assoc($returns);
            $maxRows = $results['Max(batch_no)'];
            if (empty($maxRows)) {
                $lastRows = $maxRows = 2019000000;
            } else {
                $lastRows = $maxRows + 1;
            }
            ?>
            <input type="text" name="batch_no" readonly class="org_8 org_label" required autofocus placeholder="ID" value="<?php if (!empty($lastRows)) {
                                                                                                                                echo $lastRows;
                                                                                                                            } ?>" hidden>

            <!-- /////////////////////////////////////  -->
            <div class="text-right" style="margin-right:20px">
                <input type="submit" value="Submit" name="subBtn" class="btn btn-success">
                <!-- <input type="submit" value="Cancel" name="cacel" class="btn btn-danger"> -->
            </div>

            </form>
            <!-- form end  -->
        </div>
        <!-- ----------------code here---------------->
    </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The java script plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>
<!-- registration_division_district_upazila_jqu_script -->
<script src="../js/select2.full.min.js"></script>

<script>
    function getDistrict(val) {
        $.ajax({
            type: "POST",
            url: "getReceipt_voucher.php",
            data: 'acc_code=' + val,
            success: function(data) {
                $("#district-list").html(data);
                getUpazilas();
            }
        });
    }

    function getUpazilas(val) {
        $.ajax({
            type: "POST",
            url: "getUpazilas.php",
            data: 'district_id=' + val,
            success: function(data) {
                $("#upazilla-list").html(data);
            }
        });
    }

    $(function() {
        //Initialize Select2 Elements
        $('.select2').select2()

    })
</script>
<script>
    $(document).ready(function() {
        $("#401000").addClass('active');
        $("#400000").addClass('active');
        $("#400000").addClass('is-expanded');
    });
</script>
<?php
$conn->close();
?>
</body>

</html>