<?php
session_start();
require "../database.php";
?>

<?php
//insrt query
if (isset($_POST['subBtn'])) {
    $emp_n = $_SESSION['emp_no'];
    $office_code = $_SESSION['office_code'];
    $tax_type = $_POST['tax_type'];
    $fin_year = $_POST['fin_year'];
    $active_form = $_POST['active_form'];
    $item_code = $_POST['item_code'];
    $tax_on_amount = $_POST['tax_on_amount'];
    $tax_on_rate = $_POST['tax_on_rate'];
    $is_current = $_POST['is_current'];
   
    $insertQuery = "INSERT INTO `tax_vat_rate` (`office_code`, `tax_type`, `fin_year`,`active_form`,`item_code`,`tax_on_amount`,`tax_on_rate`,`is_current`,`ss_creator`) VALUES ('$office_code','$tax_type','$fin_year','$active_form','$item_code','$tax_on_amount','$tax_on_rate','$is_current',' $emp_n')";
    $conn->query($insertQuery);
    // echo $insertQuery; exit;
    if ($conn->affected_rows == 1) {

        echo "<script>alert('Save Successfully')</script>";
    } else {
        // $message = "Save Invalid !!";
        echo "<script>alert('Save Invalid !!')</script>";
    }
    $netAmount = $tax_on_amount * $tax_on_rate;
    header("Location:vat_tax_rate_info.php");
}
?>
<?php
$query = "Select Max(acc_code) From gl_acc_code where acc_level=1";
$returnDrow = mysqli_query($conn, $query);
$resultrow = mysqli_fetch_assoc($returnDrow);
$maxRowsrow = $resultrow['Max(acc_code)'];
if (empty($maxRowsrow)) {
    $lastRowrow = $maxRowsrow = 100000000000;
} else {
    $lastRowrow = $maxRowsrow + 100000000000;
} //

?>

<?php
require "../source/top.php";
?>
<style>
    .maingltable {
        border-style: solid;
        border-width: 5px;
    }

    .maingl {
        clear: both;
        height: 50px;
        width: 100%
    }

    .leftgl {
        float: left;
        width: 33%;
    }

    .meddlegl {
        float: left;
        width: 33%
    }

    .rightgl {
        float: right;
        width: 33%
    }

    @media screen and (max-width: 800px) {

        .leftgl,
        .meddlegl,
        .rightgl {
            width: 100%;
            text-align: center;
        }
    }

    @media screen and (max-width: 500px) {

        .leftgl,
        .meddlegl,
        .rightgl {
            width: 100%;
            text-align: center;

        }
    }
</style>
<?php
require "../source/header.php";
?>
<?php
require "../source/sidebar.php";
?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Vat Tax rate Information </h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">

            <!-- ----------------code here---------------->
            <!-- top start  -->
            <div class="maingltable">
                <br>
                <div class="container">
                    <div class="maingl">
                        <div class="leftgl">
                            <p>Logo. Organigation Name</p>
                            <p>System Name</p>
                        </div>
                        <div class="meddlegl">
                            <h4>Vat Tax rate Information</h4>
                        </div>
                        <div class="rightgl">
                            <p>Process Month And Year:..-07-2019</p>
                            <p>User:xxxxxxxxxx</p>
                        </div>
                    </div>
                    <hr>
                    <div style="padding:20px;">

                        <?php
                        if (isset($netAmount)) {
                            echo $netAmount;
                        }
                       
                        ?>
                        <!-- form start  -->
                        <form method="post">
                            <!-- Office Code -->
                            <div class="form-group row">
                                <!-- <label class="col-sm-2 col-form-label">Office Code</label> -->
                                <div class="col-sm-6">
                                    <!-- <input type="text" name="office_code" class="form-control" required autofocus value=<?php if (!empty($lastRowrow)) {
                                                                                                                                    echo $lastRowrow;
                                                                                                                                } ?>> -->
                                </div>
                            </div>
                            <!-- Bank Account No. -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Tax and VAT Type</label>
                                <div class="col-sm-6">
                                    <!-- <input type="text" name="tax_type" class="form-control" id="" placeholder="Bank Account No" required> -->

                                    <select name="tax_type" class="form-control select2" required>
                                        <option value="">-Select Tax and VAT Type-</option>
                                        <?php
                                        require '../database.php';
                                        $selectQuery = 'SELECT * FROM `code_master`';
                                        $selectQueryResult = $conn->query($selectQuery);
                                        if ($selectQueryResult->num_rows) {
                                            while ($row = $selectQueryResult->fetch_assoc()) {
                                                ?>
                                        <?php
                                                echo '<option value="' . $row['id'] . '">' . $row['description'] . '</option>';
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <!-- Bank Code  -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Financial Year</label>
                                <div class="col-sm-6">
                                    <input type="text" name="fin_year" class="form-control" id="" placeholder="Enter Financial Year" required>
                                </div>
                            </div>
                            <!-- Branch name  -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Activate from</label>
                                <div class="col-sm-6">
                                    <input type="date" name="active_form" class="form-control" id="" placeholder="Enter Activate from" required>
                                </div>

                            </div>
                            <!-- Bank Address  -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Item Code </label>
                                <div class="col-sm-6">
                                    <select name="item_code" class="form-control select2" required>
                                        <option value="">-Select Item Name -</option>
                                        <?php
                                        require '../database.php';
                                        $selectQuery = 'SELECT * FROM `item`';
                                        $selectQueryResult = $conn->query($selectQuery);
                                        if ($selectQueryResult->num_rows) {
                                            while ($row = $selectQueryResult->fetch_assoc()) {
                                                ?>
                                        <?php
                                                echo '<option value="' . $row['id'] . '">' . $row['item'] . '</option>';
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <!-- General Account Code  -->
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Tax on Amount</label>
                                <div class="col-sm-6">

                                    <input type="number" name="tax_on_amount" class="form-control" id="" placeholder="Enter Tax on Amount" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Tax Vat Rate </label>
                                <div class="col-sm-6">
                                    <input type="number" name="tax_on_rate" class="form-control" id="" placeholder="Enter Tax Vat Rate Percent" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label">Is Current</label>
                                <div class="col-sm-6">
                                    <select name="is_current" id="" class="form-control select2">
                                        <option value="">-Select Any One-</option>
                                        <option value="1">YES</option>
                                        <option value="0">NO</option>

                                    </select>
                                </div>

                            </div>

                            <!-- submit  -->
                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <input type="submit" class="btn btn-primary" name="subBtn" value="submit">
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- form close  -->
                    <!-- table view start  -->
                    <div class="table-responsive border-dark border-top">
                        <table class="table table-hover">
                            <tr class="active">
                                <th>Tax Type</th>
                                <th>Financial Year</th>
                                <th>Active From </th>
                                <th>Item Code</th>
                                <th>Tax Amount</th>
                                <th>Tax Rate </th>
                                <th>Is Current</th>
                                <th>Action</th>
                            </tr>
                            <?php
                            $sql = "SELECT * FROM tax_vat_rate";
                            $query = $conn->query($sql);
                            while ($rows = $query->fetch_assoc()) {

                                echo
                                    "<tr>
									<td>" . $rows['tax_type'] . "</td>
									<td>" . $rows['fin_year'] . "</td>
									<td>" . $rows['active_form'] . "</td>
									<td>" . $rows['item_code'] . "</td>
									<td>" . $rows['tax_on_amount'] . "</td>
									<td>" . $rows['tax_on_rate'] . "</td>
									<td>" . $rows['is_current'] . "</td>
                                    <td>
                                    <a href='bank_acc_info_edit.php?recortid=" . $rows['tax_type'] . "' class='btn btn-success btn-sm><span class='glyphicon glyphicon-edit'></span>Edit</a>
									<a href='#delete_" . $rows['tax_type'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
									</td>
								</tr>";
                                // include('edit_delete_modal.php');
                            }
                            ?>
                        </table>
                    </div>
                    <!-- table view end -->
                </div>
                <!-- ----------------code here---------------->
            </div>
        </div>
</main>


<script type="text/javascript">
    $(function() {
        $("#coding_language").autocomplete({
            source: '../database.php'

        });

    });
</script>


<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The java../jcript plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>
<!-- registration_division_district_upazila_jqu_script -->

<script src="../js/select2.full.min.js"></script>

<script>
    $(function() {
        //Initialize Select2 Elements
        $('.select2').select2()

    })
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#accinfo").addClass('active');
        $("#gl_acc").addClass('active');
        $("#accinfo").addClass('is-expanded');
    });
</script>

<?php
$conn->close();
?>
</body>

</html>