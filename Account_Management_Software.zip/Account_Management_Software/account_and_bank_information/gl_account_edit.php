<?php
 session_start();
?>
<?php
require "../database.php";
//update query
if (isset($_POST['submit'])) {
  $acc_code = $_POST['acc_code'];
  $acc_head = $_POST['acc_head'];
  $postable_acc = $_POST['postable_acc'];
  $rep_glcode = $_POST['rep_glcode'];
  $category_code = $_POST['category_code'];
  $acc_type = $_POST['acc_type'];
  $ss_modifier_on = date("Y-m-d H:i:s");

  $idno = $_GET['recortid'];
  $updateQuery = "UPDATE `gl_acc_code` SET acc_code='$acc_code', acc_head='$acc_head', postable_acc='$postable_acc', rep_glcode='$rep_glcode',category_code='$category_code',acc_type='$acc_type', ss_modifier_on='$ss_modifier_on' WHERE id = '$idno'";
  // echo $updateQuery; exit;
  $conn->query($updateQuery);
  if ($conn->affected_rows == 1) {
    $message = "Update Successfully";
  }
  header("Location:gl_account.php");
}
//select query start
if (isset($_GET['recortid'])) {
  $idno = $_GET['recortid'];
  $selectQuery = "SELECT * FROM `gl_acc_code` WHERE id=$idno";
  // echo $selectQuery; exit;
  $selectQueryResult = $conn->query($selectQuery);
  //if($selectQueryResult->num_rows){		
  $row = $selectQueryResult->fetch_array();
  //}
}
?>
<?php
require "../source/top.php";
require "../source/header.php";
require "../source/sidebar.php";
?>
<style>
  .maingltable {
    border-style: solid;
    border-width: 5px;
  }

  .maingl {
    clear: both;
    height: 50px;
    width: 100%
  }

  .leftgl {
    float: left;
    width: 33%;
  }

  .meddlegl {
    float: left;
    width: 33%
  }

  .rightgl {
    float: right;
    width: 33%
  }

  @media screen and (max-width: 800px) {

    .leftgl,
    .meddlegl,
    .rightgl {
      width: 100%;
      text-align: center;
    }
  }

  @media screen and (max-width: 500px) {

    .leftgl,
    .meddlegl,
    .rightgl {
      width: 100%;
      text-align: center;

    }
  }
</style>
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i> Menu Edit</h1>
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">
      <!-- top start  -->
      <div class="maingltable">
        <div class="maingl">
          <div class="leftgl">
            <p>Logo. Organigation Name</p>
            <p>System Name</p>
          </div>
          <div class="meddlegl">

            <h2>GL Account</h2>
          </div>
          <div class="rightgl">
            <p>Process Month And Year:..-07-2019</p>
            <p>User:xxxxxxxxxx</p>
          </div>

        </div>
        <hr>
        <div style="padding:20px;">
          <!-- form start  -->
    <?php if (isset($message)) echo $message; ?>

          <form action="" method="post">
          <input type="hidden" name="recid" value="<?php echo $row['id']; ?>"/>
            <!-- acc conde  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Account Code</label>
              <div class="col-sm-6">
                <input type="text" name="acc_code" class="form-control" autofocus value="<?php echo $row['acc_code']; ?>">
              </div>
            </div>
            <!-- account name  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Account Name</label>
              <div class="col-sm-6">
                <input type="text" class="form-control" name="acc_head" value="<?php echo $row['acc_head']; ?>">
              </div>
            </div>
            <!-- post able account  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Post Level Account <br>&lpar;Ladger/Group Acc&rpar;</label>
              <div class="col-sm-6">
                <select name="postable_acc" id="" class="form-control">
                  <option value="Y" <?php if ($row['postable_acc'] == "Y") {echo 'selected="selected"';} ?>>Yes</option>
                  <option value="N" <?php if ($row['postable_acc'] == "N") {echo 'selected="selected"';} ?>>No</option>
                </select>
              </div>
            </div>
            <!-- reporting  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Reporting GL Code</label>
              <div class="col-sm-6">
                <input type="text" class="form-control" id="" name="rep_glcode" required value="<?php echo $row['rep_glcode']; ?>">
              </div>
            </div>
            <!-- category  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Category</label>
              <div class="col-sm-6">
                <select name="category_code" id="" class="form-control" required>
                  <!-- ----------------------------------->
                  <?php
                  $selectQuery = 'SELECT * FROM `code_master` WHERE `hardcode`= "acat" AND `softcode`>0';
                  $selectQueryResult =  $conn->query($selectQuery);
                  if ($selectQueryResult->num_rows) {
                    while ($rows = $selectQueryResult->fetch_assoc()) {
                      ?>
                      <option value="<?php echo $rows['softcode']; ?>" <?php if($row['category_code']==$rows['softcode']){echo "selected";} ?>><?php  echo $rows['description']; ?></option>
                    
                     <?php         
                        }
                      }
            ?>
                </select>
              </div>
            </div>
            <!-- Account Type  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Account Type</label>
              <div class="col-sm-6">
                <select name="acc_type" id="" class="form-control" required>
                  <option value="0">-----select----</option>
                  <!-- ----------------------------------->
                  <?php
                  $selectQuery = 'SELECT * FROM `code_master` WHERE `hardcode`= "acc_t" AND `softcode`>0';
                  $selectQueryResult =  $conn->query($selectQuery);
                  if ($selectQueryResult->num_rows) {
                    while ($rows = $selectQueryResult->fetch_assoc()) {
                      ?>
                      <option value="<?php echo $rows['softcode']; ?>" <?php if($row['acc_type']==$rows['softcode']){echo "selected";} ?>><?php  echo $rows['description']; ?></option>
                    
                     <?php         
                        }
                      }
            ?>
                </select>
                </select>
              </div>
            </div>
            <!-- lavel  -->
            <!-- submit  -->
            <div class="form-group row">
              <div class="col-sm-10">
                <!-- <button type="submit" class="btn btn-primary" name="subBtn">Submit</button> -->
          <input name="submit" type="submit" value="Update" class=" btn btn-primary form-control text-center" />

              </div>
            </div>
          </form>
        </div>
        <!-- form close  -->
      </div>
    </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>


<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The java../jcript plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>

<!-- registration_division_district_upazila_jqu_script -->
<script type="text/javascript">
 $(document).ready(function() {
    $("#301000").addClass('active');
    $("#300000").addClass('active');
    $("#300000").addClass('is-expanded');
  });
</script>

</body>

</html>