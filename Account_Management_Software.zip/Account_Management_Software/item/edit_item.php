<?php
session_start();
require '../database.php';
?>
<?php

$upload_dir = '../upload/';
if (isset($_POST['submit'])) {
    require '../database.php';
    // ==image name from form -name="image"==
    $imgName = $_FILES['image']['name'];
    $imgTmp = $_FILES['image']['tmp_name'];
    // ==How much image size from form $imgName == 
    $imgSize = $_FILES['image']['size'];
    // ==which EXTENSION in this image 
    $imgExt = strtolower(pathinfo($imgName, PATHINFO_EXTENSION));
    $userPic = time() . '_' . rand(1000, 9999) . '.' . $imgExt;
    move_uploaded_file($imgTmp, $upload_dir . $userPic);

    // $image = $conn->escape_string($_POST['image']);
    // echo "<script>alert($image)</script>";
    // exit;
    $name = $conn->escape_string($_POST['name']);
    $parent_id = $conn->escape_string($_POST['parent_id']);
    $item_category = $conn->escape_string($_POST['item_category']);
    $item_code = $conn->escape_string($_POST['item_code']);
    $unit_value = $conn->escape_string($_POST['unit_value']);
    $unit = $conn->escape_string($_POST['unit']);
    $sku = $conn->escape_string($_POST['sku']);
    $barcode = $conn->escape_string($_POST['barcode']);
    $sellable_option = $conn->escape_string($_POST['sellable_option']);
    $texable_option = $conn->escape_string($_POST['texable_option']);
    $pack_size = $conn->escape_string($_POST['pack_size']);
    $country_of_origin = $conn->escape_string($_POST['country_of_origin']);
    $country_of_manufacture = $conn->escape_string($_POST['country_of_manufacture']);
    $country_of_assemble = $conn->escape_string($_POST['country_of_assemble']);
    $brand_name = $conn->escape_string($_POST['brand_name']);
    $model_name = $conn->escape_string($_POST['model_name']);
    //$userid = 1;
    // $insertQuery = "INSERT INTO `item`(`id`, `item`, `parent_id`, `unit`) values (NULL,'$name','$parent_id','$unit')";
    $insertQuery = "UPDATE `item`  SET  `image`='$userPic',`item`='$name', `parent_id`='$parent_id', `item_category`='$item_category',`item_code`='$item_code', `unit_value`='$unit_value',`unit`='$unit',`sku`='$sku', `barcode`='$barcode', `sellable_option`='$sellable_option',`texable_option`='$texable_option', `pack_size`='$pack_size', `country_of_origin`='$country_of_origin', `country_of_manufacture`='$country_of_manufacture',`country_of_assemble`='$country_of_assemble', `brand_name`='$brand_name', `model_name`='$brand_name' WHERE id='" . $_GET['id'] . "'";
    // echo " $insertQuery";
    // exit;
    $conn->query($insertQuery);
    if ($conn->affected_rows == 1) {
        $message = 'Main Item Data update !!';
        // header('location: item.php');
    } else {
        $message = 'Main Item Data Update Failled !!';
    }
}
// ======GET ITEM FROM ITEM TABLE

if (isset($_GET['id'])) {
    $selectQuery = "select * from `item` where id='" . $_GET['id'] . "'";
    //   echo "$selectQuery";
    //   exit;
    $selectQueryReuslt = $conn->query($selectQuery);
    $row = $selectQueryReuslt->fetch_assoc();
    // var_dump($row);
}

?>
<?php
require '../source/top.php';
?>

<?php
require '../source/header.php';
?>
<?php
require '../source/sidebar.php';
?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Edit Item Information </h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">

            <!-- ----------------code here---------------->
            <!-- top start  -->
            <!-- <div class="maingltable"> -->
            <br>
            <div class="container">
                <div class="maingl">

                    <div class="meddlegl">
                        <h4 style="text-align:center">Edit Item Name : <?php echo $row['item']; ?></h4>
                        <?php if (isset($message)) {
                            echo "<h5 style='color:red'> $message </h5>";
                        }
                        ?>
                    </div>

                </div>
                <br>

                <!-- form start  -->
                <form method="post" action="" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <input type="hidden" class="form-control disabled" name="parent_id" value="<?php echo $row['id']; ?>" placeholder="Enter main item " required>
                    <div class="form-row form-group">
                        <label class="col-sm-2 col-form-label">Image</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="file" name="image" id="fileToUpload" class="form-control" placeholder="Image" required>
                        </div>
                        <label class="col-sm-2 col-form-label">Name</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" class="form-control" value="<?php echo $row['item']; ?>" name="name" placeholder="Enter sub item " required>
                        </div>
                    </div>
                    <!-- <input type="hidden" class="form-control" name="parent_id" value="0" placeholder="Enter main item "> -->
                    <div class="form-row form-group">
                        <label class="col-sm-2 col-form-label">Unit</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <select name="unit" class="form-control" required>
                                <?php
                                $selectQuery = 'SELECT * FROM `code_master` WHERE `softcode`>0';
                                $selectQueryResult = $conn->query($selectQuery);
                                if ($selectQueryResult->num_rows) {
                                    while ($unit = $selectQueryResult->fetch_assoc()) {
                                        echo '<option value="' . $unit['softcode'] . '">' . $unit['description'] . '</option>';
                                    }
                                }
                                // $conn->close();
                                ?>
                            </select>
                        </div>
                        <label class="col-sm-2 col-form-label">Category</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <select name="item_category" class="form-control" required>
                                <?php
                                $selectQuery = 'SELECT * FROM `code_master` WHERE `softcode`>0';
                                $selectQueryResult = $conn->query($selectQuery);
                                if ($selectQueryResult->num_rows) {
                                    while ($Category = $selectQueryResult->fetch_assoc()) {
                                        echo '<option value="' . $Category['softcode'] . '">' . $Category['description'] . '</option>';
                                    }
                                }
                                // $conn->close();
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row form-group">
                        <label class="col-sm-2 col-form-label">Code</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" class="form-control" name="item_code" value="<?php echo $row['item_code']; ?>" placeholder="Enter main item " required>
                        </div>
                        <label class="col-sm-2 col-form-label">Unit Value</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" class="form-control" name="unit_value" value="<?php echo $row['unit_value']; ?>" placeholder="Enter main item " required>
                        </div>
                    </div>


                    <div class="form-row form-group">
                        <label class="col-sm-2 col-form-label">Unit</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" class="form-control" name="unit" value="<?php echo $row['unit']; ?>" placeholder="Enter main item " required>

                        </div>
                        <label class="col-sm-2 col-form-label">SKU</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <select name="sku" class="form-control" required>
                                <?php
                                $selectQuery = 'SELECT * FROM `code_master` WHERE `softcode`>0';
                                $selectQueryResult = $conn->query($selectQuery);
                                if ($selectQueryResult->num_rows) {
                                    while ($units = $selectQueryResult->fetch_assoc()) {
                                        echo '<option value="' . $units['softcode'] . '">' . $units['description'] . '</option>';
                                    }
                                }
                                // $conn->close();
                                ?>
                            </select>
                        </div>
                    </div>


                    <div class="form-row form-group">
                        <label class="col-sm-2 col-form-label">Barcode</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" class="form-control" name="barcode" value="<?php echo $row['barcode']; ?>" placeholder="Enter main item " required>
                        </div>
                        <label class="col-sm-2 col-form-label">Sellable Option</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" class="form-control" name="sellable_option" value="<?php echo $row['sellable_option']; ?>" placeholder="Enter main item " required>
                        </div>
                    </div>

                    <div class="form-row form-group">
                        <label class="col-sm-2 col-form-label">Texable Option</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" class="form-control" name="texable_option" value="<?php echo $row['texable_option']; ?>" placeholder="Enter main item " required>
                        </div>
                        <label class="col-sm-2 col-form-label">Pack Size</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" class="form-control" name="pack_size" value="<?php echo $row['pack_size']; ?>" placeholder="Enter main item " required>
                        </div>
                    </div>
                    <div class="form-row form-group">
                        <label class="col-sm-2 col-form-label">Country Of Origin
                        </label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <select name="country_of_origin" class="form-control" required>
                                <?php
                                $selectQuery = 'SELECT * FROM `code_master` WHERE `softcode`>0';
                                $selectQueryResult = $conn->query($selectQuery);
                                if ($selectQueryResult->num_rows) {
                                    while ($region = $selectQueryResult->fetch_assoc()) {
                                        echo '<option value="' . $region['softcode'] . '">' . $region['description'] . '</option>';
                                    }
                                }
                                // $conn->close();
                                ?>
                            </select>
                        </div>
                        <label class="col-sm-2 col-form-label">Country Of Menufacture
                        </label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <select name="country_of_manufacture" class="form-control" required>
                                <?php
                                $selectQuery = 'SELECT * FROM `code_master` WHERE `softcode`>0';
                                $selectQueryResult = $conn->query($selectQuery);
                                if ($selectQueryResult->num_rows) {
                                    while ($manufac = $selectQueryResult->fetch_assoc()) {
                                        echo '<option value="' . $manufac['softcode'] . '">' . $manufac['description'] . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row form-group">
                        <label class="col-sm-2 col-form-label">Country Of Assemble</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <select name="country_of_assemble" class="form-control" required>
                                <?php
                                $selectQuery = 'SELECT * FROM `code_master` WHERE `softcode`>0';
                                $selectQueryResult = $conn->query($selectQuery);
                                if ($selectQueryResult->num_rows) {
                                    while ($seemble = $selectQueryResult->fetch_assoc()) {
                                        echo '<option value="' . $seemble['softcode'] . '">' . $seemble['description'] . '</option>';
                                    }
                                }
                                $conn->close();
                                ?>
                            </select>
                        </div>
                        <label class="col-sm-2 col-form-label"> Brand Name</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" name="brand_name" value="<?php echo $row['brand_name']; ?>" class="form-control" placeholder="Enter main item" id="memid">
                        </div>
                    </div>
                    <div class="form-row form-group">
                        <label class="col-sm-2 col-form-label">Model Name</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" name="model_name" value="<?php echo $row['model_name']; ?>" placeholder="Enter main item " class="form-control" id="memid">
                        </div>
                        <label class="col-sm-2 col-form-label"> Name</label>
                        <label class="col-form-label">:</label>
                        <div class="col">
                            <input type="text" class="form-control" readonly>
                        </div>
                    </div>

                    <td>
                        <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-primary"> + Create Item</button>
                        </div>
                    </td>


                </form>
                <!-- </div> -->
                <!-- form close  -->
            </div>
            <!-- ----------------code here---------------->
        </div>
    </div>
</main>

<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The java../jcript plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>
<!-- registration_division_district_upazila_jqu_script -->
<script src="../js/select2.full.min.js"></script>
<script src="../js/bootstrap.min"></script>


<script type="text/javascript">
    $(document).ready(function() {
        $("#accinfo").addClass('active');
        $("#gl_acc").addClass('active');
        $("#accinfo").addClass('is-expanded');
    });
</script>
<?php
//$conn->close();
?>
</body>

</html>