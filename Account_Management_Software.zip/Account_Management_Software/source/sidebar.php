<?php

include_once '../database.php';
?>
<?php
// https://www.youtube.com/watch?v=6jkaPxrYZpQ&list=PL0yiR-15Ytq9tCH5Y-InXxn8W5A1oztIq&index=6
function connect()
{
    $connect = new mysqli('localhost', 'root', '', 'acc_management');
    if (!$connect) {
        die('connection is failled in php_invoice db');
    }

    return $connect;
}
// function debug($arg)
// {
//     echo '<pre>';
//     print_r($arg);
//     echo '</pre>';
//     exit;
// }
function get_menus()
{
    $connection = connect();
    $emp_n = $_SESSION['emp_no'];
    $sql = "SELECT sm_grand_role.emp_no, sm_grand_role.menu_no, sm_menu.id, sm_menu.menu_no, sm_menu.menu_name, sm_menu.menu_obj_name, sm_menu.p_menu_no FROM sm_grand_role, sm_menu WHERE sm_grand_role.menu_no=sm_menu.menu_no AND sm_grand_role.emp_no = $emp_n";
    $result = mysqli_query($connection, $sql);
    if (mysqli_num_rows($result)) {
        $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
        $rows = $rows;
        $id = '';
        echo '<ul class="app-menu">';
        foreach ($rows as $row) {
            if ($row['p_menu_no'] == 0) {
?>
<!-- main menu -->
              <li class="treeview" id="<?php echo $row['menu_no']; ?>"><a class="app-menu__item" id="<?php echo $row['menu_no']; ?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label"><?php echo $row['menu_name']?> </span><i class="treeview-indicator fa fa-angle-right"></i></a>
<?php 
                $id = $row['id'];
                sub($rows, $id);
            } else {
            }
        }
    }
}
function sub($rows, $id)
{
    foreach ($rows as $row) {
        if ($row['p_menu_no'] == $id) {
   ?>
        <ul class="treeview-menu">
        <li><a class="treeview-item" id="<?php echo $row['menu_no']; ?>" href="<?php echo $row['menu_obj_name']; ?>"><i class="icon fa fa-circle-o"></i> <?php echo $row['menu_name']?></a></li>
        </ul>
 
        <?php
        }
    }
}
echo '</ul>';
?>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
  <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="../images/hasib.jpg" height="50px" width="50px" alt="User Image">

    <div>
    <?php if (isset($_SESSION['username'])) : ?>
        <strong>User Name:- <?php echo $_SESSION['username']; ?></strong>
        <strong>Office Code:- <?php echo $_SESSION['office_code']; ?></strong><br>
        <strong>org_website :- <?php echo $_SESSION['org_website']; ?></strong><br>
        <strong> <?php echo $_SESSION['org_tel']; ?></strong><br>
      <?php endif; ?>
      <p class="app-sidebar__user-designation">Backend Developer</p>
    </div>
  </div>
 
  <ul class="app-menu">
    <li><a class="app-menu__item" id="dashboard" href="../index/index.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
    <!-- sample menu -->
    <?php get_menus(); ?>
   
    <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">transation</span><i class="treeview-indicator fa fa-angle-right"></i></a>
        <ul class="treeview-menu">
          <li><a class="treeview-item" href="../transation/bank_acc_info.php"><i class="icon fa fa-circle-o"></i> Bank account Information</a></li>
          <li><a class="treeview-item" href="../transation/Chq_book_info.php"><i class="icon fa fa-circle-o"></i> Cheque Book Information</a></li>
          <li><a class="treeview-item" href="../transation/Chq_leaf_info.php"><i class="icon fa fa-circle-o"></i> Cheque Leaf Information</a></li>
          <li><a class="treeview-item" href="../transation/vat_tax_rate_info.php"><i class="icon fa fa-circle-o"></i> VAT Tax Rate Info</a></li>
        </ul>
      </li>
      <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Report</span><i class="treeview-indicator fa fa-angle-right"></i></a>
        <ul class="treeview-menu">
          <li><a class="treeview-item" href="../report/transation_details.php"><i class="icon fa fa-circle-o"></i> Jurnal</a></li>
          <li><a class="treeview-item" href="../report/balance_sheet.php"><i class="icon fa fa-circle-o"></i>Balance Sheet</a></li>
          <li><a class="treeview-item" href="../report/gl_ledger.php"><i class="icon fa fa-circle-o"></i>GL Ledger</a></li>
          <li><a class="treeview-item" href="../report/inc_exp.php"><i class="icon fa fa-circle-o"></i>Income and Expenditure</a></li>
          <li><a class="treeview-item" href="../report/chart_of_account.php"><i class="icon fa fa-circle-o"></i>Chart Of Account</a></li>
        </ul>
      </li>
      <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Item</span><i class="treeview-indicator fa fa-angle-right"></i></a>
        <ul class="treeview-menu">
          <li><a class="treeview-item" href="../item/item.php"><i class="icon fa fa-circle-o"></i> Item Product</a></li>
          <li><a class="treeview-item" href="../item/item.php"><i class="icon fa fa-circle-o"></i>Stock</a></li>
         </ul>
      </li>

      <li class="treeview"><a class="app-menu__item" href="../transation/day_closed.php"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Day Closed</span></i></a>
      </li>




  </ul>
</aside>


<!-- https://codewithawa.com/posts/admin-and-user-login-in-php-and-mysql-database -->
<!-- https://phppot.com/php/php-login-script-with-session/
https://www.w3school.info/2015/12/22/steps-to-create-dynamic-multilevel-menu-using-php-and-mysql/
https://www.codeofaninja.com/2013/03/php-login-script.html -->