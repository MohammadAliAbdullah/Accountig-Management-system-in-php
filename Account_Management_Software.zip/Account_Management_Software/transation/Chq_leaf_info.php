<?php
session_start();
require "../database.php";
?>
<?php
//insrt query
if (isset($_POST['subBtn'])) {

    $emp_n = $_SESSION['emp_no'];
    $office_code = $_SESSION['office_code'];
    $bank_code = $_POST['bank_code'];
    $branck_code = $_POST['branch_code'];
    $account_no = $_POST['account_no'];
    $beg_chq_no = $_POST['beg_chq_no'];
    $chq_leaf_no = $_POST['chq_leaf_no'];
    $status_date = $_POST['status_date'];


    $insertQuery = "INSERT INTO `bank_chq_leaf_info` (`office_code`,`bank_code`,`branch_code`,`account_no`,`beg_chq_no`,`chq_leaf_no`,`status_date`,`ss_creator`) VALUES ('$office_code','$bank_code','$branck_code','$account_no','$beg_chq_no','$chq_leaf_no','$status_date',' $emp_n')";
    $conn->query($insertQuery);
    // echo $insertQuery; exit;
    if ($conn->affected_rows == 1) {

        echo "<script>alert('Save Successfully')</script>";
    } else {
        // $message = "Save Invalid !!";
        echo "<script>alert('Save Invalid !!')</script>";
    }

    header("Location:chq_book_info.php");
}
?>
<?php
$query = "Select Max(acc_code) From gl_acc_code where acc_level=1";
$returnDrow = mysqli_query($conn, $query);
$resultrow = mysqli_fetch_assoc($returnDrow);
$maxRowsrow = $resultrow['Max(acc_code)'];
if (empty($maxRowsrow)) {
    $lastRowrow = $maxRowsrow = 100000000000;
} else {
    $lastRowrow = $maxRowsrow + 100000000000;
} //

?>

<?php
require "../source/top.php";
?>
<style>
    .maingltable {
        border-style: solid;
        border-width: 5px;
    }

    .maingl {
        clear: both;
        height: 50px;
        width: 100%
    }

    .leftgl {
        float: left;
        width: 33%;
    }

    .meddlegl {
        float: left;
        width: 33%
    }

    .rightgl {
        float: right;
        width: 33%
    }

    @media screen and (max-width: 800px) {

        .leftgl,
        .meddlegl,
        .rightgl {
            width: 100%;
            text-align: center;
        }
    }

    @media screen and (max-width: 500px) {

        .leftgl,
        .meddlegl,
        .rightgl {
            width: 100%;
            text-align: center;

        }
    }
</style>
<?php
require "../source/header.php";
?>
<?php
require "../source/sidebar.php";
?>
<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i> Bank Cheque leaf Information </h1>
        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">

            <!-- ----------------code here---------------->
            <!-- top start  -->

            <!-- form close  -->
            <!-- table view start  -->
            <div class="table-responsive">
                <table class="table table-hover">
                    <tr class="active">
                        <th>Office Code</th>
                        <th>Bankk Account No</th>
                        <th>Bank Code </th>
                        <th>Branch Code</th>
                        <th>Cheque No</th>
                        <th>Cheque Leaf No</th>
                        <th>Date </th>
                        <th>Creator</th>

                    </tr>
                    <?php
                    $sql = "SELECT * FROM bank_chq_leaf_info";
                    $query = $conn->query($sql);
                    while ($rows = $query->fetch_assoc()) {
                        echo
                            "<tr>
									<td>" . $rows['office_code'] . "</td>
									<td>" . $rows['account_no'] . "</td>
									<td>" . $rows['bank_code'] . "</td>
									<td>" . $rows['branch_code'] . "</td>
                                    <td>" . $rows['beg_chq_no'] . "</td>
									<td>" . $rows['chq_leaf_no'] . "</td>                                    
									<td>" . $rows['status_date'] . "</td>
									<td>" . $rows['ss_creator'] . "</td>
                                 
								</tr>";
                        // include('edit_delete_modal.php');
                    }
                    ?>
                </table>
            </div>
            <!-- table view end -->
        </div>
        <!-- ----------------code here---------------->
    </div>
    </div>
</main>

<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The java../jcript plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>
<!-- registration_division_district_upazila_jqu_script -->
<script type="text/javascript">
    $(document).ready(function() {
        $("#accinfo").addClass('active');
        $("#gl_acc").addClass('active');
        $("#accinfo").addClass('is-expanded');
    });
</script>
<?php
$conn->close();
?>

<!-- <td>
    <a href='bank_acc_info_edit.php?recortid=" . $rows[' account_no'] . "' class='btn btn-success btn-sm><span class='glyphicon glyphicon-edit'></span>Edit</a>
									<a href='#delete_" . $rows['account_no'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
									</td> -->
</body>

</html>