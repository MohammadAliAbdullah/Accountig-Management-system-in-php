<?php
 session_start();
?>
<?php
require "../database.php";
?>
<?php
//insrt query
if (isset($_POST['subBtn'])) {
  $acc_code = $_POST['acc_code'];
  $acc_head = $_POST['acc_head'];
  $postable_acc = $_POST['postable_acc'];
  $rep_glcode = $_POST['rep_glcode'];
  $category_code = $_POST['category_code'];
  $acc_level = $_POST['acc_level'];
  $acc_type= $_POST['acc_type'];
  $parent_acc_code = $_POST['parent_acc_code'];



  $insertQuery = "INSERT INTO `gl_acc_code` (`id`, `acc_code`, `acc_head`, `postable_acc`,`rep_glcode`,`category_code`,`acc_level`,`parent_acc_code`,`ss_creator_on`) VALUES (NULL,'$acc_code','$acc_head','$postable_acc','$rep_glcode','$category_code','$acc_level','$parent_acc_code',now())";

  $conn->query($insertQuery);
  // echo $insertQuery; exit;
  if ($conn->affected_rows == 1) {
    $message = "Save Successfully";
  }

  header("Location:gl_account.php");
}
?>
<?php
$query = "Select Max(acc_code) From gl_acc_code where acc_level=1";
$returnDrow = mysqli_query($conn, $query);
$resultrow = mysqli_fetch_assoc($returnDrow);
$maxRowsrow = $resultrow['Max(acc_code)'];
if (empty($maxRowsrow)) {
  $lastRowrow = $maxRowsrow = 100000000000;
} else {
  $lastRowrow = $maxRowsrow + 100000000000;
}

?>

<?php
require "../source/top.php";
?>
<style>
  .maingltable {
    border-style: solid;
    border-width: 5px;
  }

  .maingl {
    clear: both;
    height: 50px;
    width: 100%
  }

  .leftgl {
    float: left;
    width: 33%;
  }

  .meddlegl {
    float: left;
    width: 33%
  }

  .rightgl {
    float: right;
    width: 33%
  }

  @media screen and (max-width: 800px) {

    .leftgl,
    .meddlegl,
    .rightgl {
      width: 100%;
      text-align: center;
    }
  }

  @media screen and (max-width: 500px) {

    .leftgl,
    .meddlegl,
    .rightgl {
      width: 100%;
      text-align: center;

    }
  }
</style>
<?php
require "../source/header.php";
?>
<?php
require "../source/sidebar.php";
?>
<main class="app-content">
  <div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i>General Ladger Account Add</h1>
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
    </ul>
  </div>
  <div class="row">
    <div class="col-md-12">

      <!-- ----------------code here---------------->
      <!-- top start  -->
      <div class="maingltable">
        <div class="maingl">
          <div class="leftgl">
            <p>Logo. Organigation Name</p>
            <p>System Name</p>
          </div>
          <div class="meddlegl">
            <h2>GL Account</h2>
          </div>
          <div class="rightgl">
            <p>Process Month And Year:..-07-2019</p>
            <p>User:xxxxxxxxxx</p>
          </div>
        </div>
        <hr>
        <div style="padding:20px;">
          <!-- form start  -->
          <form action="" method="post">
            <!-- acc conde  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Account Code</label>
              <div class="col-sm-6">
                <input type="text" readonly name="acc_code" class="form-control" required autofocus value=<?php if (!empty($lastRowrow)) {echo $lastRowrow;} ?>>
              </div>
            </div>
            <!-- account name  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Account Name</label>
              <div class="col-sm-6">
                <input type="text" class="form-control" id="" name="acc_head" required>
              </div>
            </div>
            <!-- post able account  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Post Level Account <br>&lpar;Ladger/Group Acc&rpar;</label>
              <div class="col-sm-6">
                <select name="postable_acc" class="form-control" required>
                <option value="">Select</option>
              <option value="Y">Yes</option>
              <option value="N">No</option>
                </select>
              </div>
            </div>
            <!-- reporting  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Reporting GL Code</label>
              <div class="col-sm-6">
                <input type="text" class="form-control" id="" name="rep_glcode" required>
              </div>
            </div>
            <!-- category  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Category</label>
              <div class="col-sm-6">
                <select name="category_code" id="" class="form-control" required>
                  <!-- ----------------------------------->
                  <?php
                  $selectQuery = 'SELECT * FROM `code_master` WHERE `hardcode`= "acat" AND `softcode`>0';
                  $selectQueryResult =  $conn->query($selectQuery);
                  if ($selectQueryResult->num_rows) {
                    while ($row = $selectQueryResult->fetch_assoc()) {
                      echo '<option value="' . $row['softcode'] . '">'  . $row['description'] . '</option>';
                    }
                  }
                  ?>
                </select>
              </div>
            </div>
            <!-- Account Type  -->
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Account Type</label>
              <div class="col-sm-6">
                <select name="acc_type" id="" class="form-control" required>
                  <!-- ----------------------------------->
                  <?php
                  $selectQuery = 'SELECT * FROM `code_master` WHERE `hardcode`= "acc_t" AND `softcode`>0';
                  $selectQueryResult =  $conn->query($selectQuery);
                  if ($selectQueryResult->num_rows) {
                    while ($row = $selectQueryResult->fetch_assoc()) {
                      echo '<option value="' . $row['softcode'] . '">'  . $row['description'] . '</option>';
                    }
                  }
                  ?>
                </select>
              </div>
            </div>
            <!-- lavel  -->
            <input type="number" name="acc_level" class="form-control" value="1" hidden>
            <input type="number" class="form-control" name="parent_acc_code" value="0" hidden>

            <!-- submit  -->
            <div class="form-group row">
              <div class="col-sm-10">
                <button type="submit" class="btn btn-primary" name="subBtn">Submit</button>
              </div>
            </div>
          </form>
        </div>
        <!-- form close  -->
        <!-- table view start  -->
        <div class="table-responsive border-dark border-top">
          <table class="table table-hover">
            <tr class="active">
              <th>ID</th>
              <th>Category</th>
              <th>Account Code</th>
              <th>Account Name</th>
              <th>GL Code</th>
              <th>Parent Acc</th>
              <th>Postable</th>
              <th>Account Level</th>
              <th>Account Type</th>
              <th>Add Sub Menu</th>
            </tr>
            <?php
            $sql = "SELECT gl_acc_code.id, gl_acc_code.category_code,gl_acc_code.acc_code,gl_acc_code.acc_head,gl_acc_code.rep_glcode,gl_acc_code.parent_acc_code,gl_acc_code.postable_acc,gl_acc_code.acc_level,gl_acc_code.acc_type,code_master.hardcode,code_master.softcode,code_master.description,code_master.sort_des FROM gl_acc_code,code_master where gl_acc_code.category_code=code_master.softcode AND code_master.hardcode='acat' ORDER by acc_code";
            $query = $conn->query($sql);
            while ($rows = $query->fetch_assoc()) {
              echo
                "<tr>
									<td>" . $rows['id'] . "</td>
									<td>" . $rows['description'] . "</td>
									<td>" . $rows['acc_code'] . "</td>
									<td>" . $rows['acc_head'] . "</td>
									<td>" . $rows['rep_glcode'] . "</td>
									<td>" . $rows['parent_acc_code'] . "</td>
									<td>" . $rows['postable_acc'] . "</td>
									<td>" . $rows['acc_level'] . "</td>
									<td>" . $rows['acc_type'] . "</td>
                  <td><a target='_blank' href='gl_account_add.php?id=" . $rows['id'] . "' class='btn btn-success btn-sm><span class='glyphicon glyphicon-edit'></span>Add Sub Account</a>
                  <a href='gl_account_edit.php?recortid=" . $rows['id'] . "' class='btn btn-success btn-sm><span class='glyphicon glyphicon-edit'></span>Edit</a>
										<a href='#delete_" . $rows['id'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
									</td>
								</tr>";
              include('edit_delete_modal.php');
            }
            ?>
          </table>
        </div>
        <!-- table view end -->
      </div>
      <!-- ----------------code here---------------->
    </div>
  </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The javascript plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>
<!-- Page specific javascripts-->
<!-- Data table plugin-->
<script type="text/javascript" src="../js/plugins/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../js/plugins/dataTables.bootstrap.min.js"></script>
<!-- registration_division_district_upazila_jqu_script -->
<script type="text/javascript">
  $(document).ready(function() {
    $("#301000").addClass('active');
    $("#300000").addClass('active');
    $("#300000").addClass('is-expanded');
  });
</script>
<?php
$conn->close();
?>
</body>

</html>