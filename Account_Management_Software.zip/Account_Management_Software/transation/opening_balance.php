<!-- ----------------------------------
#######################################
###     Create By: Hasibuzzaman     ###
###     Date: 19-11-2019            ###
###     Mob: 01738356180            ###
#######################################
-------------------------------------->
<?php
session_start();
require "../database.php";
?>
<?php

if (isset($_POST['subBtn'])) {
    // $trn_no = $_POST['trn_no'];
    // $office_code = $_POST['office_code'];
    // $year_code = $_POST['year_code'];
    $batch_no = $_POST['batch_no'];
    $tran_date = $_POST['tran_date'];
    // $by_account = $_POST['by_account'];
    $toaccount = $_POST['toaccount'];
    $tran_mode = $_POST['tran_mode'];
    // $vaucher_type = $_POST['vaucher_type'];
    $particular = $_POST['particular'];
    $draccount = $_POST['draccount'];
    $craccount = $_POST['craccount'];
    $ss_creator = $_POST['ss_creator'];
    // $ss_org_no = $_POST['ss_org_no'];



    // $insertQuery = "INSERT INTO `tran_details` (`office_code`,`year_code`,`batch_no`, `tran_date`, `gl_acc_code`,`tran_mode`,`vaucher_type`, `description`, `dr_amt_loc`,`cr_amt_loc`,`ss_creator`,`ss_creator_on`,`ss_org_no`) VALUES ('$office_code','$year_code','$batch_no','$tran_date','$toaccount','$tran_mode','$vaucher_type','$particular','$craccount','$ss_creator',now(),'$ss_org_no')";
    $insertQuery = "INSERT INTO `tran_details` (`batch_no`, `tran_date`, `gl_acc_code`,`tran_mode`,`description`, `dr_amt_loc`,`cr_amt_loc`,`ss_creator`,`ss_creator_on`) VALUES ('$batch_no','$tran_date','$toaccount','$tran_mode','$particular','$draccount','$craccount','$ss_creator',now())";
    $conn->query($insertQuery);
    // echo $insertQuery;exit;
    if ($conn->affected_rows == 1) {
        $message = "Save Successfully";
    }
}
?>

<?php
require "../source/top.php";
require "../source/header.php";
require "../source/sidebar.php";
?>

<main class="app-content">
    <div class="app-title">
        <div>
            <h1><i class="fa fa-dashboard"></i>Opening Balance</h1>
            <?php if (isset($message)) echo $message; ?>
            <?php if (isset($messagecr)) echo $messagecr; ?>
            <?php if (isset($messages)) echo $messages; ?>
            <?php if (isset($messagescr)) echo $messages; ?>

        </div>
        <ul class="app-breadcrumb breadcrumb">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
        </ul>
    </div>
    <div class="row">
        <!-- ----------------code here---------------->
        <div class="c_main">
            <?php
            $query = "Select Max(tran_no) From tran_details";
            $return = mysqli_query($conn, $query);
            $result = mysqli_fetch_assoc($return);
            $maxRow = $result['Max(tran_no)'];
            if (empty($maxRow)) {
                $lastRow = $maxRow = 2019000000;
            } else {
                $lastRow = $maxRow + 1;
            }
            ?>
            <!-- head -->
            <div class="c_head">
                <!-- form start  -->
                <form method="post">
                    <div class="c_main_left"><br>
                        <div class="org_row org_group">
                            <label class="org_4 org_label">Transaction No</label>
                            <div class="org_6">
                                <!-- <input type="text" name="trn_no" readonly class="org_8 org_label" required autofocus > -->
                                <input type="text" readonly class="org_8 org_form" required autofocus placeholder="ID" value="<?php if (!empty($lastRow)) {
                                                                                                                                    echo $lastRow;
                                                                                                                                } ?>">

                            </div>
                        </div>
                    </div>
                    <div class="c_main_right">
                        <div class="org_row org_group">
                            <label class="org_4 org_label">Transaction Date</label>
                            <div class="org_6">
                                <input type="date" name="tran_date" id="date" class="org_form">
                                <script>
                                    var date = new Date();
                                    const dateInput = document.querySelector('#date');
                                    var month = date.getMonth() + 1;
                                    if (month < 10) {
                                        month = `0${month}`;
                                    }
                                    var dateValue = `${date.getFullYear()}-${month}-${date.getDate()}`;
                                    dateInput.value = `${dateValue}`;
                                </script>
                            </div>
                        </div>
                        <div class="org_row org_group">
                            <label class="org_4 org_label">User ID</label>
                            <div class="org_6">
                                <?php if (isset($_SESSION['username'])) : ?>
                                    <input type="text" name="ss_creator" id="" value="<?php echo $_SESSION['username']; ?>" class="org_form" readonly>
                                <?php endif; ?>


                            </div>
                        </div>

                    </div>
            </div>

            <!-- 2nd section  -->
            <div class="c_form_div">
                <div class="form-row" style="width:98%">
                    <div class="form-group col-md-3">
                        <label>To Account</label>
                        <select class="form-control select2" name="toaccount" required>
                            <option value="">---Select---</option>
                            <?php
                            $selectQuery = "SELECT * FROM `gl_acc_code` where postable_acc= 'Y' ORDER by acc_code";
                            $selectQueryResult =  $conn->query($selectQuery);
                            if ($selectQueryResult->num_rows) {
                                while ($row = $selectQueryResult->fetch_assoc()) {
                                    echo '<option value="' . $row['acc_code'] . '">'  . $row['acc_head'] . '</option>';
                                }
                            }
                            ?>
                        </select>

                    </div>
                    <div class="form-group col-md-3">
                        <label for="inputPassword4">Particular</label>
                        <input type="text" class="form-control" name="particular">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="inputPassword4">Dr. Amount</label>
                        <input type="text" class="form-control" name="draccount">
                    </div>
                    <div class="form-group col-md-3">
                        <label for="inputPassword4">Cr. Amount</label>
                        <input type="text" class="form-control" name="craccount">
                    </div>
                </div>
            </div>
            <!-- hidden  -->

            <input type="hidden" class="form-control" name="tran_mode" value="OP">

            <!-- batch_no -->
            <?php
            $querys = "Select Max(batch_no) From tran_details";
            $returns = mysqli_query($conn, $querys);
            $results = mysqli_fetch_assoc($returns);
            $maxRows = $results['Max(batch_no)'];
            if (empty($maxRows)) {
                $lastRows = $maxRows = 2019000000;
            } else {
                $lastRows = $maxRows + 1;
            }
            ?>
            <input type="text" name="batch_no" readonly class="form-control" required autofocus placeholder="ID" value="<?php if (!empty($lastRows)) {
                                                                                                                            echo $lastRows;
                                                                                                                        } ?>" hidden>

            <!-- /////////////////////////////////////  -->
            <div class="text-right" style="margin-right:20px">
                <input type="submit" value="Submit" name="subBtn" class="btn btn-success">
                <!-- <input type="submit" value="Cancel" name="cacel" class="btn btn-danger"> -->
            </div>

            </form>
            <!-- form end  -->
        </div>
        <!-- ----------------code here---------------->
    </div>
</main>
<!-- Essential javascripts for application to work-->
<script src="../js/jquery-3.2.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/main.js"></script>
<!-- The java script plugin to display page loading on top-->
<script src="../js/plugins/pace.min.js"></script>
<!-- serch option js -->
<script src="../js/select2.full.min.js"></script>
<script>
    $(function() {
        //Initialize Select2 Elements
        $('.select2').select2()

    })
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#transation").addClass('active');
        $("#receipt").addClass('active');
        $("#transation").addClass('is-expanded');
    });
</script>
<?php
$conn->close();
?>
</body>

</html>