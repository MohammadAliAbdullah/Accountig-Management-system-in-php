<?php

//database_connection.php

$connect = new PDO("mysql:host=localhost; dbname=acc_management;", "root", "");

function fill_select_box($connect, $category_id)
{
 $query = "SELECT * FROM `gl_acc_code` where postable_acc= 'Y' ORDER by acc_code";

 $statement = $connect->prepare($query);

 $statement->execute();

 $result = $statement->fetchAll();

 $output = '';

 foreach($result as $row)
 {
  $output .= '<option value="'.$row["acc_code"].'">'.$row["acc_head"].'</option>';
 }

 return $output;
}

?>